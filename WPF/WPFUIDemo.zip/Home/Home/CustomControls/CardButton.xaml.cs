﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Home.CustomControls
{
    /// <summary>
    /// CardButton.xaml 的交互逻辑
    /// </summary>
    public partial class CardButton : UserControl
    {
        public CardButton()
        {
            InitializeComponent();
        }


        public Uri imageSource
        {
            get { return (Uri)GetValue(imageSourceProperty); }
            set { SetValue(imageSourceProperty, value); }
        }

        public static readonly DependencyProperty imageSourceProperty =
            DependencyProperty.Register("imageSource", typeof(Uri), typeof(CardButton));



        public string text1
        {
            get { return (string)GetValue(text1Property); }
            set { SetValue(text1Property, value); }
        }

        public static readonly DependencyProperty text1Property =
            DependencyProperty.Register("text1", typeof(string), typeof(CardButton));



        public string text2
        {
            get { return (string)GetValue(text2Property); }
            set { SetValue(text2Property, value); }
        }

        public static readonly DependencyProperty text2Property =
            DependencyProperty.Register("text2", typeof(string), typeof(CardButton));

        public SolidColorBrush IconBackground
        {
            get { return (SolidColorBrush)GetValue(IconBackgroundProperty); }
            set { SetValue(IconBackgroundProperty, value); }
        }

        public static readonly DependencyProperty IconBackgroundProperty =
            DependencyProperty.Register("IconBackground", typeof(SolidColorBrush), typeof(CardButton));

        public SolidColorBrush IconBackgroundMouseOver
        {
            get { return (SolidColorBrush)GetValue(IconBackgroundMouseOverProperty); }
            set { SetValue(IconBackgroundMouseOverProperty, value); }
        }

        public static readonly DependencyProperty IconBackgroundMouseOverProperty =
            DependencyProperty.Register("IconBackgroundMouseOver", typeof(SolidColorBrush), typeof(CardButton));

        public Brush ProgressTextColor
        {
            get { return (Brush)GetValue(ProgressTextProperty); }
            set { SetValue(ProgressTextProperty, value); }
        }

        public static readonly DependencyProperty ProgressTextProperty =
            DependencyProperty.Register("ProgressTextColor", typeof(Brush), typeof(CardButton));

        public FontWeight ProgressTextWeight
        {
            get { return (FontWeight)GetValue(ProgressTextWeightProperty); }
            set { SetValue(ProgressTextWeightProperty, value); }
        }

        public static readonly DependencyProperty ProgressTextWeightProperty =
            DependencyProperty.Register("ProgressTextWeight", typeof(FontWeight), typeof(CardButton));

        public Brush ProgressTextColorMouseOver
        {
            get { return (Brush)GetValue(ProgressTextColorMouseOverProperty); }
            set { SetValue(ProgressTextColorMouseOverProperty, value); }
        }

        public static readonly DependencyProperty ProgressTextColorMouseOverProperty =
            DependencyProperty.Register("ProgressTextColorMouseOver", typeof(Brush), typeof(CardButton));

        public FontWeight ProgressTextWeightMouseOver
        {
            get { return (FontWeight)GetValue(ProgressTextWeightMouseOverProperty); }
            set { SetValue(ProgressTextWeightMouseOverProperty, value); }
        }

        public static readonly DependencyProperty ProgressTextWeightMouseOverProperty =
            DependencyProperty.Register("ProgressTextWeightMouseOver", typeof(FontWeight), typeof(CardButton));


        public int Progress
        {
            get { return (int)GetValue(ProgressProperty); }
            set { SetValue(ProgressProperty, value); }
        }
        public int ProgressBarThickness
        {
            get { return (int)GetValue(ProgressBarThicknessProperty); }
            set { SetValue(ProgressBarThicknessProperty, value); }
        }

        public static readonly DependencyProperty ProgressBarThicknessProperty =
            DependencyProperty.Register("ProgressBarThickness", typeof(int), typeof(CardButton));

        public static readonly DependencyProperty ProgressProperty =
            DependencyProperty.Register("Progress", typeof(int), typeof(CardButton));

        public Brush ProgressIndicatorBrush
        {
            get { return (Brush)GetValue(ProgressIndicatorBrushProperty); }
            set { SetValue(ProgressIndicatorBrushProperty, value); }
        }

        public static readonly DependencyProperty ProgressIndicatorBrushProperty =
            DependencyProperty.Register("ProgressIndicatorBrush", typeof(Brush), typeof(CardButton));

        public Brush ProgressBackgroundBrush
        {
            get { return (Brush)GetValue(ProgressBackgroundBrushProperty); }
            set { SetValue(ProgressBackgroundBrushProperty, value); }
        }

        public static readonly DependencyProperty ProgressBackgroundBrushProperty =
            DependencyProperty.Register("ProgressBackgroundBrush", typeof(Brush), typeof(CardButton));

        public Brush ProgressIndicatorBrushMouseOver
        {
            get { return (Brush)GetValue(ProgressIndicatorBrushMouseOverProperty); }
            set { SetValue(ProgressIndicatorBrushMouseOverProperty, value); }
        }

        public static readonly DependencyProperty ProgressIndicatorBrushMouseOverProperty =
            DependencyProperty.Register("ProgressIndicatorBrushMouseOver", typeof(Brush), typeof(CardButton));

        public Brush ProgressBackgroundBrushMouseOver
        {
            get { return (Brush)GetValue(ProgressBackgroundBrushMouseOverProperty); }
            set { SetValue(ProgressBackgroundBrushMouseOverProperty, value); }
        }

        public static readonly DependencyProperty ProgressBackgroundBrushMouseOverProperty =
            DependencyProperty.Register("ProgressBackgroundBrushMouseOver", typeof(Brush), typeof(CardButton));

    }
}
