﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Home.CustomControls
{
    /// <summary>
    /// Paginator.xaml 的交互逻辑
    /// </summary>
    public partial class Paginator : UserControl
    {
        public static readonly DependencyProperty TotalPagesProperty =
            DependencyProperty.Register("TotalPages", typeof(int), typeof(Paginator), new PropertyMetadata(1));

        public static readonly DependencyProperty CurrentPageProperty =
            DependencyProperty.Register("CurrentPage", typeof(int), typeof(Paginator), new PropertyMetadata(1, OnCurrentPageChanged));

        public static readonly DependencyProperty PageSizeProperty =
            DependencyProperty.Register("PageSize", typeof(int), typeof(Paginator), new PropertyMetadata(10));

        public int TotalPages
        {
            get => (int)GetValue(TotalPagesProperty);
            set => SetValue(TotalPagesProperty, value);
        }

        public int CurrentPage
        {
            get => (int)GetValue(CurrentPageProperty);
            set => SetValue(CurrentPageProperty, value);
        }

        public int PageSize
        {
            get => (int)GetValue(PageSizeProperty);
            set => SetValue(PageSizeProperty, value);
        }

        public event Action<int> PageChanged;

        public Paginator()
        {
            InitializeComponent();
            Loaded += Paginator_Loaded;
        }

        private void Paginator_Loaded(object sender, RoutedEventArgs e)
        {
            UpdatePageInfo();
        }

        private static void OnCurrentPageChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var paginator = (Paginator)d;
            paginator.UpdatePageInfo();
            paginator.PageChanged?.Invoke(paginator.CurrentPage);
        }

        private void UpdatePageInfo()
        {
            PageComboBox.Items.Clear();
            for (int i = 1; i <= TotalPages; i++)
            {
                PageComboBox.Items.Add(i);
            }

            PageComboBox.SelectedItem = CurrentPage;

            PageInfoText.Text = $"{CurrentPage} / {TotalPages}";
            PrevButton.IsEnabled = CurrentPage > 1;
            NextButton.IsEnabled = CurrentPage < TotalPages;
        }

        private void PrevButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentPage > 1)
            {
                CurrentPage--;
            }
        }

        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentPage < TotalPages)
            {
                CurrentPage++;
            }
        }

        private void PageComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (PageComboBox.SelectedItem is int selectedPage)
            {
                CurrentPage = selectedPage;
            }
        }
    }
}
