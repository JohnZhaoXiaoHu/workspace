﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Home.CustomControls
{
    /// <summary>
    /// DataCard.xaml 的交互逻辑
    /// </summary>
    public partial class DataCard : UserControl
    {
        public DataCard()
        {
            InitializeComponent();
        }


        public Geometry PathData
        {
            get { return (Geometry)GetValue(PathDataProperty); }
            set { SetValue(PathDataProperty, value); }
        }

        public static readonly DependencyProperty PathDataProperty = 
            DependencyProperty.Register("PathData", typeof(Geometry), typeof(DataCard));

        public string MainText
        {
            get { return (string)GetValue(MainTextProperty); }
            set { SetValue(MainTextProperty, value); }
        }

        public static readonly DependencyProperty MainTextProperty =
            DependencyProperty.Register("MainText", typeof(string), typeof(DataCard));

        public string MainValue
        {
            get { return (string)GetValue(MainValueProperty); }
            set { SetValue(MainValueProperty, value); }
        }

        public static readonly DependencyProperty MainValueProperty =
            DependencyProperty.Register("MainValue", typeof(string), typeof(DataCard));

        public string SubValue
        {
            get { return (string)GetValue(SubValueProperty); }
            set { SetValue(SubValueProperty, value); }
        }

        public static readonly DependencyProperty SubValueProperty =
            DependencyProperty.Register("SubValue", typeof(string), typeof(DataCard));

        public string LastMonthValue
        {
            get { return (string)GetValue(LastMonthValueProperty); }
            set { SetValue(LastMonthValueProperty, value); }
        }

        public static readonly DependencyProperty LastMonthValueProperty =
            DependencyProperty.Register("LastMonthValue", typeof(string), typeof(DataCard));

        public string CurrentMonthValue
        {
            get { return (string)GetValue(CurrentMonthValueProperty); }
            set { SetValue(CurrentMonthValueProperty, value); }
        }

        public static readonly DependencyProperty CurrentMonthValueProperty =
            DependencyProperty.Register("CurrentMonthValue", typeof(string), typeof(DataCard));
    }
}
