﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;

namespace Home.CustomControls
{
    public partial class ControlPanel : UserControl, INotifyPropertyChanged
    {
        private int _value;

        public int Value
        {
            get { return _value; }
            set
            {
                if (_value != value)
                {
                    _value = value;
                    OnPropertyChanged(nameof(Value));  
                }
            }
        }

        public ICommand ChangeValueCommand { get; }

        public event PropertyChangedEventHandler PropertyChanged;

        public ControlPanel()
        {
            InitializeComponent();
            this.DataContext = this;  

            
            ChangeValueCommand = new RelayCommand<int>(ChangeValue);
        }

       
        private void ChangeValue(int changeAmount)
        {
            Value = changeAmount; 
        }

        
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class RelayCommand<T> : ICommand
    {
        private readonly Action<T> _execute;
        private readonly Func<T, bool> _canExecute;

        public RelayCommand(Action<T> execute)
            : this(execute, null)
        {
        }

        public RelayCommand(Action<T> execute, Func<T, bool> canExecute)
        {
            _execute = execute;
            _canExecute = canExecute;
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public bool CanExecute(object parameter)
        {
            return _canExecute == null || _canExecute((T)parameter);
        }

        public void Execute(object parameter)
        {
           
            if (parameter is string strValue)
            {
                if (int.TryParse(strValue, out int intValue))
                {
                    _execute((T)(object)intValue);
                }
            }
            else if (parameter is T)
            {
                _execute((T)parameter);
            }
        }
    }

    public class ValueToPercentConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is int intValue)
            {
                return intValue / 255.0 * 100;
            }
            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is string stringValue && stringValue.EndsWith("%"))
            {
                string numericPart = stringValue.TrimEnd('%');
                if (int.TryParse(numericPart, out int result))
                {
                    return (int)(result / 100.0 * 255); 
                }
            }
            return value;
        }
    }
}
