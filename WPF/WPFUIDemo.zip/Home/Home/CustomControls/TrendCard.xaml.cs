﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LiveCharts;
using LiveCharts.Defaults;
using LiveCharts.Wpf;
using LiveCharts.Wpf.Charts.Base;

namespace Home.CustomControls
{
    /// <summary>
    /// TrendCard.xaml 的交互逻辑
    /// </summary>
    public partial class TrendCard : UserControl
    {
        public TrendCard()
        {
            InitializeComponent();
            Chart.Series = new SeriesCollection();
        }

        public string text1
        {
            get { return (string)GetValue(text1Property); }
            set { SetValue(text1Property, value); }
        }

        public static readonly DependencyProperty text1Property =
            DependencyProperty.Register("text1", typeof(string), typeof(TrendCard));



        public string text2
        {
            get { return (string)GetValue(text2Property); }
            set { SetValue(text2Property, value); }
        }

        public static readonly DependencyProperty text2Property =
            DependencyProperty.Register("text2", typeof(string), typeof(TrendCard));

        public string text3
        {
            get { return (string)GetValue(text3Property); }
            set { SetValue(text3Property, value); }
        }

        public static readonly DependencyProperty text3Property =
            DependencyProperty.Register("text3", typeof(string), typeof(TrendCard));

        public string text4
        {
            get { return (string)GetValue(text4Property); }
            set { SetValue(text4Property, value); }
        }

        public static readonly DependencyProperty text4Property =
            DependencyProperty.Register("text4", typeof(string), typeof(TrendCard));


        public static readonly DependencyProperty ChartSeriesProperty =
            DependencyProperty.Register(
                nameof(ChartSeries),          
                typeof(SeriesCollection),   
                typeof(TrendCard),   
                new PropertyMetadata(null, OnChartSeriesChanged));
        
        public SeriesCollection ChartSeries
        {
            get => (SeriesCollection)GetValue(ChartSeriesProperty);
            set => SetValue(ChartSeriesProperty, value);
        }

       
        private static void OnChartSeriesChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as TrendCard;
            if (control != null && e.NewValue is SeriesCollection newSeries)
            {
                control.Chart.Series = newSeries;

                control.Chart.AxisX[0].ShowLabels = false;
                control.Chart.AxisY[0].ShowLabels = false;

                foreach (var series in newSeries)
                {
                    if (series is LineSeries lineSeries)
                    {
                       
                        lineSeries.Fill = System.Windows.Media.Brushes.Transparent;
                        lineSeries.PointGeometrySize = 1;
                    }
                }
            }
        }



    }
}
