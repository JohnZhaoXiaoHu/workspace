﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Home.CustomControls
{
    /// <summary>
    /// CardButtonMin.xaml 的交互逻辑
    /// </summary>
    public partial class CardButtonMin : UserControl
    {
        public CardButtonMin()
        {
            InitializeComponent();
        }

        #region Properties

       
        public Geometry PathData
        {
            get { return (Geometry)GetValue(PathDataProperty); }
            set { SetValue(PathDataProperty, value); }
        }

        public static readonly DependencyProperty PathDataProperty =
            DependencyProperty.Register("PathData", typeof(Geometry), typeof(CardButtonMin));

        public string TitleText
        {
            get { return (string)GetValue(TitleTextProperty); }
            set { SetValue(TitleTextProperty, value); }
        }

        public static readonly DependencyProperty TitleTextProperty =
            DependencyProperty.Register("TitleText", typeof(string), typeof(CardButtonMin));

        public string DescriptionText
        {
            get { return (string)GetValue(DescriptionTextProperty); }
            set { SetValue(DescriptionTextProperty, value); }
        }

        public static readonly DependencyProperty DescriptionTextProperty =
            DependencyProperty.Register("DescriptionText", typeof(string), typeof(CardButtonMin));

        public string NumText
        {
            get { return (string)GetValue(NumTextProperty); }
            set { SetValue(NumTextProperty, value); }
        }

        public static readonly DependencyProperty NumTextProperty =
            DependencyProperty.Register("NumText", typeof(string), typeof(CardButtonMin));

        #endregion
    }
}
