﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Home.CustomControls
{
    /// <summary>
    /// ChangeCard.xaml 的交互逻辑
    /// </summary>
    public partial class ChangeCard : UserControl
    {
        public int Value
        {
            get { return (int)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }

        public static readonly DependencyProperty ValueProperty =
            DependencyProperty.Register("Value", typeof(int), typeof(ChangeCard));

        public ChangeCard()
        {
            InitializeComponent();
            DataContext = this; 
        }

        private void DecreaseButton_Click(object sender, RoutedEventArgs e)
        {
           
            int inputValue = 0;
            if (int.TryParse(textBox.Text, out inputValue))
            {
                Value -= inputValue; 
            }
        }

        private void IncreaseButton_Click(object sender, RoutedEventArgs e)
        {
            
            int inputValue = 0;
            if (int.TryParse(textBox.Text, out inputValue))
            {
                Value += inputValue;
            }
        }
    }

}
