﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LiveCharts;

namespace Home.ViewModels
{

    public class TrendViewModel
    {
        public ChartValues<int> ChartData { get; set; }

        public TrendViewModel()
        {
            ChartData = new ChartValues<int> { 1, 2, 3 };
        }
    }
}
