﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static Home.Pages.HomePage;

namespace Home.Pages
{
    /// <summary>
    /// DataBasePage.xaml 的交互逻辑
    /// </summary>
    public partial class DataBasePage : Page, INotifyPropertyChanged
    {
        private int _currentStep;

        public int CurrentStep
        {
            get => _currentStep;
            set
            {
                if (_currentStep != value)
                {
                    _currentStep = value;
                    OnPropertyChanged(nameof(CurrentStep));  
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        public ObservableCollection<EquipRecord> EquipRecords { get; set; }
        public DataBasePage()
        {
            InitializeComponent();

            EquipRecords = new ObservableCollection<EquipRecord>
            {
                new EquipRecord { Num = "001", EquipNum = "E001", EquipName = "设备1", EquipStyle = "类型A", EquipAddress = "地址1", Productor = "生产商1", Total = "100", Uint = "台", Step= 1 },
                new EquipRecord { Num = "002", EquipNum = "E002", EquipName = "设备2", EquipStyle = "类型B", EquipAddress = "地址2", Productor = "生产商2", Total = "200", Uint = "台" , Step= 5},
                new EquipRecord { Num = "003", EquipNum = "E003", EquipName = "设备3", EquipStyle = "类型A", EquipAddress = "地址3", Productor = "生产商3", Total = "300", Uint = "台" ,Step= 2},
                new EquipRecord { Num = "004", EquipNum = "E004", EquipName = "设备4", EquipStyle = "类型C", EquipAddress = "地址4", Productor = "生产商4", Total = "400", Uint = "台" ,Step= 4},
                new EquipRecord { Num = "005", EquipNum = "E005", EquipName = "设备5", EquipStyle = "类型B", EquipAddress = "地址5", Productor = "生产商5", Total = "500", Uint = "台" ,Step= 4},
                new EquipRecord { Num = "006", EquipNum = "E006", EquipName = "设备6", EquipStyle = "类型A", EquipAddress = "地址6", Productor = "生产商6", Total = "600", Uint = "台" , Step = 6},
                new EquipRecord { Num = "007", EquipNum = "E007", EquipName = "设备7", EquipStyle = "类型C", EquipAddress = "地址7", Productor = "生产商7", Total = "700", Uint = "台" , Step = 7},
                new EquipRecord { Num = "008", EquipNum = "E008", EquipName = "设备8", EquipStyle = "类型B", EquipAddress = "地址8", Productor = "生产商8", Total = "800", Uint = "台" , Step = 1},
                new EquipRecord { Num = "009", EquipNum = "E009", EquipName = "设备9", EquipStyle = "类型A", EquipAddress = "地址9", Productor = "生产商9", Total = "900", Uint = "台" , Step = 3},
                new EquipRecord { Num = "010", EquipNum = "E010", EquipName = "设备10", EquipStyle = "类型C", EquipAddress = "地址10", Productor = "生产商10", Total = "1000", Uint = "台" },
                new EquipRecord { Num = "011", EquipNum = "E011", EquipName = "设备11", EquipStyle = "类型A", EquipAddress = "地址11", Productor = "生产商11", Total = "1100", Uint = "台" },
                new EquipRecord { Num = "012", EquipNum = "E012", EquipName = "设备12", EquipStyle = "类型B", EquipAddress = "地址12", Productor = "生产商12", Total = "1200", Uint = "台" },
                new EquipRecord { Num = "013", EquipNum = "E013", EquipName = "设备13", EquipStyle = "类型C", EquipAddress = "地址13", Productor = "生产商13", Total = "1300", Uint = "台" },
                new EquipRecord { Num = "014", EquipNum = "E014", EquipName = "设备14", EquipStyle = "类型A", EquipAddress = "地址14", Productor = "生产商14", Total = "1400", Uint = "台" },
                new EquipRecord { Num = "015", EquipNum = "E015", EquipName = "设备15", EquipStyle = "类型B", EquipAddress = "地址15", Productor = "生产商15", Total = "1500", Uint = "台" },
                new EquipRecord { Num = "016", EquipNum = "E016", EquipName = "设备16", EquipStyle = "类型C", EquipAddress = "地址16", Productor = "生产商16", Total = "1600", Uint = "台" },
                new EquipRecord { Num = "017", EquipNum = "E017", EquipName = "设备17", EquipStyle = "类型A", EquipAddress = "地址17", Productor = "生产商17", Total = "1700", Uint = "台" },
                new EquipRecord { Num = "018", EquipNum = "E018", EquipName = "设备18", EquipStyle = "类型B", EquipAddress = "地址18", Productor = "生产商18", Total = "1800", Uint = "台" },
                new EquipRecord { Num = "019", EquipNum = "E019", EquipName = "设备19", EquipStyle = "类型A", EquipAddress = "地址19", Productor = "生产商19", Total = "1900", Uint = "台" },
                new EquipRecord { Num = "020", EquipNum = "E020", EquipName = "设备20", EquipStyle = "类型C", EquipAddress = "地址20", Productor = "生产商20", Total = "2000", Uint = "台" },
                new EquipRecord { Num = "021", EquipNum = "E021", EquipName = "设备21", EquipStyle = "类型B", EquipAddress = "地址21", Productor = "生产商21", Total = "2100", Uint = "台" },
                new EquipRecord { Num = "022", EquipNum = "E022", EquipName = "设备22", EquipStyle = "类型A", EquipAddress = "地址22", Productor = "生产商22", Total = "2200", Uint = "台" },
                new EquipRecord { Num = "023", EquipNum = "E023", EquipName = "设备23", EquipStyle = "类型B", EquipAddress = "地址23", Productor = "生产商23", Total = "2300", Uint = "台" },
                new EquipRecord { Num = "024", EquipNum = "E024", EquipName = "设备24", EquipStyle = "类型C", EquipAddress = "地址24", Productor = "生产商24", Total = "2400", Uint = "台" },
                new EquipRecord { Num = "025", EquipNum = "E025", EquipName = "设备25", EquipStyle = "类型A", EquipAddress = "地址25", Productor = "生产商25", Total = "2500", Uint = "台" },
                new EquipRecord { Num = "026", EquipNum = "E026", EquipName = "设备26", EquipStyle = "类型B", EquipAddress = "地址26", Productor = "生产商26", Total = "2600", Uint = "台" },
                new EquipRecord { Num = "027", EquipNum = "E027", EquipName = "设备27", EquipStyle = "类型C", EquipAddress = "地址27", Productor = "生产商27", Total = "2700", Uint = "台" },
                new EquipRecord { Num = "028", EquipNum = "E028", EquipName = "设备28", EquipStyle = "类型A", EquipAddress = "地址28", Productor = "生产商28", Total = "2800", Uint = "台" },
                new EquipRecord { Num = "029", EquipNum = "E029", EquipName = "设备29", EquipStyle = "类型B", EquipAddress = "地址29", Productor = "生产商29", Total = "2900", Uint = "台" },
                new EquipRecord { Num = "030", EquipNum = "E030", EquipName = "设备30", EquipStyle = "类型C", EquipAddress = "地址30", Productor = "生产商30", Total = "3000", Uint = "台" },
            };

            // 设置页面的 DataContext
            DataContext = this;
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (DataGrid.SelectedItem is EquipRecord selectedRecord)
            {
                CurrentStep = selectedRecord.Step;
            }
        }
    }

    public class EquipRecord
    {
        public int Step { get; set; }
        public bool IsSelected { get; set; }
        public string Num { get; set; }
        public string EquipNum { get; set; }
        public string EquipName { get; set; }
        public string EquipStyle { get; set; }
        public string EquipAddress { get; set; }
        public string Productor { get; set; }
        public string Total { get; set; }

        public string Uint { get; set; }
    }
}
