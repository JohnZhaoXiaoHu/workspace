﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using Home.CustomControls;
using LiveCharts;
using LiveCharts.Defaults;
using LiveCharts.Wpf;

namespace Home.Pages
{
    /// <summary>
    /// OS.xaml 的交互逻辑
    /// </summary>
    public partial class OS : Page
    {
        public SeriesCollection ChartData1 { get; set; }
        public SeriesCollection ChartData2 { get; set; }
        public SeriesCollection ChartData3 { get; set; }
        public OS()
        {
            InitializeComponent();

            ChartData1 = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "Sample Data1",
                    Values = new ChartValues<double> { 3, 5, 7, 4 },
                    Stroke = Brushes.Green
                }
            };

            ChartData2 = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "Sample Data2",
                    Values = new ChartValues<double> { 7, 6, 5, 4 },
                    Stroke = Brushes.Red
                }
            };

            ChartData3 = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "Sample Data3",
                    Values = new ChartValues<double> { 17, 26, 15, 14 },
                    Stroke = Brushes.Orange
                }
            };

            var data = new ObservableCollection<MyItem>
            {
                new MyItem { Num = "1", ImageUrl = "/Assets/Images/设备1.png", EquipName="开料机", EquipStyle="生产设备",EquipAddress="开料车间",StartTime="2024-10-11",Status="启用", Progress = 50 },
                new MyItem { Num = "2", ImageUrl = "/Assets/Images/设备2.png", EquipName="CPU", EquipStyle="办公设备",EquipAddress="办公室",StartTime="2024-10-11",Status="报废", Progress = 100 },
                new MyItem { Num = "3", ImageUrl = "/Assets/Images/设备3.png", EquipName="文件", EquipStyle="办公设备",EquipAddress="办公室",StartTime="2024-10-11",Status="报废", Progress = 100 },
                new MyItem { Num = "4", ImageUrl = "/Assets/Images/设备4.png", EquipName="线缆", EquipStyle="辅助设备",EquipAddress="仓库",StartTime="2024-10-11",Status="启用", Progress = 60 },
                new MyItem { Num = "5", ImageUrl = "/Assets/Images/设备5.png", EquipName="硬盘", EquipStyle="办公设备",EquipAddress="办公室",StartTime="2024-10-11",Status="启用", Progress = 71 },
                new MyItem { Num = "6", ImageUrl = "/Assets/Images/设备6.png", EquipName="数据库", EquipStyle="软件设备",EquipAddress="办公室",StartTime="2024-10-11",Status="启用", Progress = 88 },
                new MyItem { Num = "7", ImageUrl = "/Assets/Images/设备1.png", EquipName="数据库", EquipStyle="软件设备",EquipAddress="办公室",StartTime="2024-10-11",Status="启用", Progress = 88 },
            };
            dataGrid.ItemsSource = data;

            DataContext = this;

        }

        public class MyItem
        {
            public string Num { get; set; }
            public string ImageUrl { get; set; }
            public string EquipName { get; set; }
            public string EquipStyle { get; set; }
            public string EquipAddress { get; set; }
            public string StartTime { get; set; }
            public string Status { get; set; }
            public double Progress { get; set; }
        }
    }
}
