﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Home.Pages
{
    /// <summary>
    /// RealTime.xaml 的交互逻辑
    /// </summary>
    public partial class RealTime : Page
    {
        public ObservableCollection<string> ComboBoxItems1 { get; set; }
        public ObservableCollection<string> ComboBoxItems2 { get; set; }
        public ObservableCollection<string> ComboBoxItems3 { get; set; }
        public RealTime()
        {
            InitializeComponent();
            DrawRadarChart(new[] { 80, 60, 90, 70, 50 }, new[] { "A", "B", "C", "D", "E" });
            ComboBoxItems1 = new ObservableCollection<string>
            {
                "安东尼",
                "蜘蛛侠",
                "雷神",
                "孙悟空",
                "二郎神",
            };

            ComboBoxItems2 = new ObservableCollection<string>
            {
                "当天",
                "当周",
                "当月",
                "当年",
            };

            ComboBoxItems3 = new ObservableCollection<string>
            {
                "生产部门",
                "职能部门",
                "后勤部门",
            };
            DataContext = this;
        }

        private void DrawRadarChart(int[] values, string[] labels)
        {
            int levels = 5; 
            int maxValue = 100; 
            double radius = 120; 
            double centerX = RadarCanvas.ActualWidth / 2;
            double centerY = RadarCanvas.ActualHeight / 2;

            RadarCanvas.Loaded += (s, e) =>
            {
                centerX = RadarCanvas.ActualWidth / 2;
                centerY = RadarCanvas.ActualHeight / 2;

                for (int i = 1; i <= levels; i++)
                {
                    double levelRadius = radius * i / levels;
                    Polygon levelPolygon = CreatePolygon(levelRadius, labels.Length, centerX, centerY);
                    levelPolygon.Stroke = Brushes.Green;
                    levelPolygon.StrokeThickness = 1;
                    RadarCanvas.Children.Add(levelPolygon);
                }

                for (int i = 0; i < labels.Length; i++)
                {
                    double angle = i * 2 * Math.PI / labels.Length;
                    double x = centerX + radius * Math.Cos(angle);
                    double y = centerY + radius * Math.Sin(angle);
                    Line axis = new Line
                    {
                        X1 = centerX,
                        Y1 = centerY,
                        X2 = x,
                        Y2 = y,
                        Stroke = Brushes.Green,
                        StrokeThickness = 1
                    };
                    RadarCanvas.Children.Add(axis);

                    TextBlock label = new TextBlock
                    {
                        Text = labels[i],
                        Foreground = Brushes.Green,
                        FontSize = 16,
                        FontWeight = FontWeights.Bold
                    };

                    double labelOffset = 20; 
                    Canvas.SetLeft(label, x + labelOffset * Math.Cos(angle) - 10);
                    Canvas.SetTop(label, y + labelOffset * Math.Sin(angle) - 10);
                    RadarCanvas.Children.Add(label);
                }

                Polygon dataPolygon = CreatePolygon(radius, labels.Length, centerX, centerY, values, maxValue);
                dataPolygon.Stroke = Brushes.Red;
                dataPolygon.StrokeThickness = 2;
                dataPolygon.Fill = Brushes.LightYellow;
                dataPolygon.Opacity = 0.5;
                RadarCanvas.Children.Add(dataPolygon);
            };
        }

        private Polygon CreatePolygon(double radius, int pointsCount, double centerX, double centerY, int[] values = null, int maxValue = 100)
        {
            Polygon polygon = new Polygon();
            for (int i = 0; i < pointsCount; i++)
            {
                double angle = i * 2 * Math.PI / pointsCount;
                double valueFactor = values != null ? (double)values[i] / maxValue : 1;
                double x = centerX + radius * valueFactor * Math.Cos(angle);
                double y = centerY + radius * valueFactor * Math.Sin(angle);
                polygon.Points.Add(new Point(x, y));
            }
            return polygon;
        }
    }
}
