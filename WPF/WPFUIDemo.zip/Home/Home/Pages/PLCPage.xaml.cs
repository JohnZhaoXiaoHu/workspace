﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LiveCharts;
using LiveCharts.Wpf;

namespace Home.Pages
{
    /// <summary>
    /// PLCPage.xaml 的交互逻辑
    /// </summary>
    public partial class PLCPage : Page
    {
        public ObservableCollection<string> ComboBoxItems1 { get; set; }
        public ObservableCollection<string> ComboBoxItems2 { get; set; }
        public ObservableCollection<string> ComboBoxItems3 { get; set; }
        public ObservableCollection<string> ComboBoxItems4 { get; set; }
        public ObservableCollection<string> ComboBoxItems5 { get; set; }
        public ObservableCollection<ColumnSeries> SeriesCollection { get; set; }
        public ObservableCollection<ColumnSeries> SeriesPriceCollection { get; set; }

        public PLCPage()
        {
            InitializeComponent();

            Numbers = new string[] { "电能", "水能", "天然气", "生物燃气", "石油", "太阳能", "风能", "氢气" };
            SeriesCollection = new ObservableCollection<ColumnSeries>
            {
                new ColumnSeries
                {
                    Title = "昨日",
                    Values = new ChartValues<double> { 62, 77, 77, 45, 15, 100, 15, 16 }
                },
                new ColumnSeries
                {
                    Title = "今日",
                    Values = new ChartValues<double> { 44, 34, 23, 12, 15, 43, 54, 56 }
                }
            };

            SeriesPriceCollection = new ObservableCollection<ColumnSeries>
            {
                new ColumnSeries
                {
                    Title = "昨日总价",
                    Values = new ChartValues<double> {82, 86, 88, 66, 77, 88, 98, 78 }
                },
                new ColumnSeries
                {
                    Title = "今日总价",
                    Values = new ChartValues<double> { 85, 86, 76, 97, 77, 77, 67, 89 }
                }
            };
            ComboBoxItems1 = new ObservableCollection<string>
        {
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6",
            "COM7",
        };
            ComboBoxItems2 = new ObservableCollection<string>
        {
                "4800",
            "9600",
            "19200",
            "38400",
            "57600",
            "115200",
        };
            ComboBoxItems3 = new ObservableCollection<string>
        {
            "5",
            "6",
            "7",
            "8",
        };
            ComboBoxItems4 = new ObservableCollection<string>
        {
            "1",
            "1.5",
            "2",
        };

            ComboBoxItems5 = new ObservableCollection<string>
        {
            "None",
            "Even",
            "Odd",
            "Mark",
            "Space",
        };
            this.DataContext = this;
        }

        public string[] Numbers { get; set; }

    }
}
