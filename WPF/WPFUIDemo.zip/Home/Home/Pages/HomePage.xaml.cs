﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Home.Pages
{
    /// <summary>
    /// HomePage.xaml 的交互逻辑
    /// </summary>
    public partial class HomePage : Page
    {
        private List<AlarmRecord> _allAlarmRecords;
        private const int PageSize = 13; 

        public HomePage()
        {
            InitializeComponent();
            _allAlarmRecords = GetAlarmRecords();
            Paginator_PageChanged(0);
            Paginator.TotalPages = (_allAlarmRecords.Count + PageSize - 1) / PageSize;
            Paginator.CurrentPage = 1;
        }

        private List<AlarmRecord> GetAlarmRecords()
        {
            var records = new List<AlarmRecord>();
            for (int i = 0; i < 100; i++)
            {
                records.Add(new AlarmRecord
                {
                    AlarmEquip = $"Equip{i + 1}",
                    AlarmIndex = $"Alarm{i + 1}",
                    AlarmValue = $"{i * 10}",
                    AlarmCompare = "AlarmStyle",
                    AlarmThreshold = "100",
                    AlarmTime = DateTime.Now.AddMinutes(-i).ToString(),
                    AlarmLevel = i % 3 == 0 ? "INFO" : (i % 3 == 1 ? "WARN" : "ALARM")
                });
            }
            return records;
        }

        private void Paginator_PageChanged(int page)
        {
            var pagedData = _allAlarmRecords.Skip((page - 1) * PageSize).Take(PageSize).ToList();
            AlarmRecordDataGrid.ItemsSource = pagedData;
        }

        public class AlarmRecord
        {
            public bool IsSelected { get; set; }
            public string AlarmEquip { get; set; }
            public string AlarmIndex { get; set; }

            public string AlarmValue { get; set; }

            public string AlarmCompare { get; set; }

            public string AlarmThreshold { get; set; }
            public string AlarmTime { get; set; }
            public string AlarmLevel { get; set; }


        }
    }
}
