﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LiveCharts.Wpf;
using LiveCharts;
using System.Windows.Threading;

namespace Home.Pages
{
    /// <summary>
    /// EmbeddedPage.xaml 的交互逻辑
    /// </summary>
    public partial class EmbeddedPage : Page, INotifyPropertyChanged
    {
        private DispatcherTimer _timer;
        private string _currentTime;
        public string CurrentTime
        {
            get => _currentTime;
            set
            {
                if (_currentTime != value)
                {
                    _currentTime = value;
                    OnPropertyChanged(nameof(CurrentTime));
                }
            }
        }
        private int _value;
        public ObservableCollection<string> TimeLabels { get; set; }
        public int Value
        {
            get => _value;
            set
            {
                if (_value != value)
                {
                    _value = value;
                    OnPropertyChanged(nameof(Value)); 
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public ObservableCollection<ColumnSeries> SeriesPriceCollection1 { get; set; }
        public ObservableCollection<ColumnSeries> SeriesPriceCollection2 { get; set; }
        public EmbeddedPage()
        {
            InitializeComponent();
            TimeLabels = new ObservableCollection<string>();
            SeriesPriceCollection1 = new ObservableCollection<ColumnSeries>
            {
                new ColumnSeries
                {
                    Title = "速度",
                    Values = new ChartValues<int> {}
                },
                new ColumnSeries
                {
                    Title = "温度",
                    Values = new ChartValues<int> {}
                }
            };
            SeriesPriceCollection2 = new ObservableCollection<ColumnSeries>
            {
                new ColumnSeries
                {
                    Title = "速度",
                    Values = new ChartValues<int> {}
                },
                new ColumnSeries
                {
                    Title = "温度",
                    Values = new ChartValues<int> {}
                }
            };
            DataContext = this;

            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromSeconds(1);
            _timer.Tick += Timer_Tick; 
            _timer.Start();  
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            var newValue1 = ControlPanel1.Value;
            var newValue2 = ControlPanel2.Value;
            var random = new Random();
            var randomValue1 = (int)random.Next(0, 100);
            var randomValue2 = (int)random.Next(0, 100);
            AddValueToSeries(SeriesPriceCollection1[0], newValue1);
            AddValueToSeries(SeriesPriceCollection1[1], randomValue1);
            AddValueToSeries(SeriesPriceCollection2[0], newValue2);
            AddValueToSeries(SeriesPriceCollection2[1], randomValue2);

            UpdateTimeLabels();

            var currentTime = DateTime.Now.ToString("HH:mm:ss");
            TimeLabels.Add(currentTime);
        }

        private void AddValueToSeries(ColumnSeries series, int value)
        {
            series.Values.Add(value);

            if (series.Values.Count > 10)
            {
                series.Values.RemoveAt(0); 
            }
        }

        private void UpdateTimeLabels()
        {
            if (TimeLabels.Count > 10)
            {
                TimeLabels.RemoveAt(0);  
            }
        }


    }
}
