﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO.Ports;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Shell;

namespace ModbusDemo
{
    public class ModbusDemoViewModel : INotifyPropertyChanged
    {
        // 属性通知实现
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        // 串口配置属性
        private string _selectedPort;
        public string SelectedPort
        {
            get => _selectedPort;
            set
            {
                _selectedPort = value;
                OnPropertyChanged(nameof(SelectedPort));
            }
        }

        private int _selectedBaudRate;
        public int SelectedBaudRate
        {
            get => _selectedBaudRate;
            set
            {
                _selectedBaudRate = value;
                OnPropertyChanged(nameof(SelectedBaudRate));
            }
        }

        private int _selectedDataBits;
        public int SelectedDataBits
        {
            get => _selectedDataBits;
            set
            {
                _selectedDataBits = value;
                OnPropertyChanged(nameof(SelectedDataBits));
            }
        }

        private Parity _selectedParity;
        public Parity SelectedParity
        {
            get => _selectedParity;
            set
            {
                _selectedParity = value;
                OnPropertyChanged(nameof(SelectedParity));
            }
        }

        private StopBits _selectedStopBits;
        public StopBits SelectedStopBits
        {
            get => _selectedStopBits;
            set
            {
                _selectedStopBits = value;
                OnPropertyChanged(nameof(SelectedStopBits));
            }
        }

        // 连接状态属性
        private bool _isConnected;
        public bool IsConnected
        {
            get => _isConnected;
            set
            {
                _isConnected = value;
                OnPropertyChanged(nameof(IsConnected));

                if (IsConnected)
                {
                    StartReading(); // 开始读取数据
                }
            }
        }

        // Modbus Helper 实例
        private ModbusRTUHelper _modbusHelper;

        // Commands
        public ICommand ConnectCommand { get; }
        public ICommand WriteLightingCommand { get; }
        public ICommand WriteTvCommand { get; }
        public ICommand WriteKettleCommand { get; }
        public ICommand WriteACStartStopCommand { get; }
        public ICommand WriteACModeCommand { get; }
        public ICommand WriteACTempratureCommand { get; }

        // 配置选项
        public ObservableCollection<string> PortNameSelect { get; set; }
        public ObservableCollection<int> BaudRateSelect { get; set; }
        public ObservableCollection<int> DataBitsSelect { get; set; }
        public ObservableCollection<Parity> ParitySelect { get; set; }
        public ObservableCollection<StopBits> StopBitsSelect { get; set; }

        // 控制变量
        private bool _lighting;
        public bool Lighting
        {
            get => _lighting;
            set
            {
                _lighting = value;
                OnPropertyChanged(nameof(Lighting));
            }
        }

        private bool _tv;
        public bool Tv
        {
            get => _tv;
            set
            {
                _tv = value;
                OnPropertyChanged(nameof(Tv));
            }
        }

        private bool _kettle;
        public bool Kettle
        {
            get => _kettle;
            set
            {
                _kettle = value;
                OnPropertyChanged(nameof(Kettle));
            }
        }

        private bool _run;
        public bool Run
        {
            get => _run;
            set
            {
                _run = value;
                OnPropertyChanged(nameof(Run));
            }
        }

        // 温湿度相关属性
        private ushort _outsideTemprature;
        public ushort OutsideTemprature
        {
            get => _outsideTemprature;
            set
            {
                _outsideTemprature = value;
                OnPropertyChanged(nameof(OutsideTemprature));
            }
        }

        private ushort _insideTemprature;
        public ushort InsideTemprature
        {
            get => _insideTemprature;
            set
            {
                _insideTemprature = value;
                OnPropertyChanged(nameof(InsideTemprature));
            }
        }

        private ushort _humidity;
        public ushort Humidity
        {
            get => _humidity;
            set
            {
                _humidity = value;
                OnPropertyChanged(nameof(Humidity));
            }
        }

        private ushort _cloudy;
        public ushort Cloudy
        {
            get => _cloudy;
            set
            {
                _cloudy = value;
                OnPropertyChanged(nameof(Cloudy));
            }
        }

        // AC温度调节相关属性
        private ushort _sliderValue;
        public ushort SliderValue
        {
            get => _sliderValue;
            set
            {
                if (_sliderValue != value) // 判断值是否变化
                {
                    _sliderValue = value;
                    OnPropertyChanged(nameof(SliderValue)); // 通知UI更新
                    WriteACTemprature(value); // 执行实际命令
                }
            }
        }

        // 构造函数，初始化配置项及命令
        public ModbusDemoViewModel()
        {
            // 获取可用串口列表
            PortNameSelect = new ObservableCollection<string>(SerialPort.GetPortNames());

            // 初始化波特率、数据位、校验位、停止位
            BaudRateSelect = new ObservableCollection<int> { 4800, 9600, 19200, 38400, 57600, 115200 };
            DataBitsSelect = new ObservableCollection<int> { 5, 6, 7, 8 };
            ParitySelect = new ObservableCollection<Parity>(Enum.GetValues(typeof(Parity)).Cast<Parity>());
            StopBitsSelect = new ObservableCollection<StopBits>(Enum.GetValues(typeof(StopBits)).Cast<StopBits>());

            // 设置默认值
            SelectedBaudRate = 19200;
            SelectedDataBits = 8;
            SelectedParity = Parity.None;
            SelectedStopBits = StopBits.One;

            // 初始化命令
            ConnectCommand = new RelayCommand(Connect);
            WriteLightingCommand = new RelayCommand(WriteLighting);
            WriteTvCommand = new RelayCommand(WriteTv);
            WriteKettleCommand = new RelayCommand(WriteKettle);
            WriteACStartStopCommand = new RelayCommand(WriteACStartStop);
            WriteACModeCommand = new RelayCommand<string>(WriteACMode);
            WriteACTempratureCommand = new RelayCommand<int>(WriteACTemprature);

            // 启动数据读取
            StartReading();
        }

        // 连接或断开连接
        private void Connect()
        {
            // 初始化 Modbus Helper
            _modbusHelper = new ModbusRTUHelper(SelectedPort, SelectedBaudRate, SelectedDataBits, SelectedParity, SelectedStopBits);

            if (IsConnected)
            {
                _modbusHelper.Close(); // 断开连接
                IsConnected = false;
            }
            else
            {
                _modbusHelper.Open(); // 打开连接
                IsConnected = true;
            }
        }

        // 启动数据读取，定时每秒读取一次
        private async void StartReading()
        {
            while (true)
            {
                // 如果没有连接，则停止循环
                if (!IsConnected)
                {
                    break;
                }

                Read(); // 执行读取数据

                await Task.Delay(1000); // 每隔1秒读取一次
            }
        }

        // 执行 Modbus 数据读取
        private void Read()
        {
            if (_modbusHelper == null)
            {
                MessageBox.Show("串口未打开或已断开，请检查连接！");
                return;
            }

            byte slaveAddress = 1;
            ushort startAddress = 0;
            ushort numberOfPoints = 4;

            // 读取输入状态
            bool[] inputs = _modbusHelper.ReadInputs(slaveAddress, startAddress, numberOfPoints);
            Lighting = inputs[0];
            Tv = inputs[1];
            Kettle = inputs[2];
            Run = inputs[3];

            // 读取输入寄存器
            ushort[] register = _modbusHelper.ReadInputRegisters(slaveAddress, startAddress, numberOfPoints);
            OutsideTemprature = register[0];
            InsideTemprature = register[1];
            Humidity = register[2];
            Cloudy = register[3];
        }

        // 写入 Lighting 状态
        private void WriteLighting()
        {
            if (_modbusHelper == null)
            {
                MessageBox.Show("串口未打开或已断开，请检查连接！");
                return;
            }

            byte slaveAddress = 1;
            ushort coilAddress = 0;
            bool value = !Lighting; // 切换状态
            _modbusHelper.WriteSingleCoil(slaveAddress, coilAddress, value);
        }

        // 写入 TV 状态
        private void WriteTv()
        {
            if (_modbusHelper == null)
            {
                MessageBox.Show("串口未打开或已断开，请检查连接！");
                return;
            }

            byte slaveAddress = 1;
            ushort coilAddress = 1;
            bool value = !Tv;
            _modbusHelper.WriteSingleCoil(slaveAddress, coilAddress, value);
        }

        // 写入 Kettle 状态
        private void WriteKettle()
        {
            if (_modbusHelper == null)
            {
                MessageBox.Show("串口未打开或已断开，请检查连接！");
                return;
            }

            byte slaveAddress = 1;
            ushort coilAddress = 2;
            bool value = !Kettle;
            _modbusHelper.WriteSingleCoil(slaveAddress, coilAddress, value);
        }

        // 写入 AC 启动停止状态
        private void WriteACStartStop()
        {
            if (_modbusHelper == null)
            {
                MessageBox.Show("串口未打开或已断开，请检查连接！");
                return;
            }

            byte slaveAddress = 1;
            ushort coilAddress = 3;
            bool value = !Run;
            _modbusHelper.WriteSingleCoil(slaveAddress, coilAddress, value);
        }

        // 写入 AC 模式
        private void WriteACMode(string parameter)
        {
            if (_modbusHelper == null)
            {
                MessageBox.Show("串口未打开或已断开，请检查连接！");
                return;
            }

            byte slaveAddress = 1;
            ushort coilAddress = 0;
            ushort value = parameter switch
            {
                "制冷" => 1,
                "除湿" => 2,
                "送风" => 3,
                "自动" => 4,
                _ => 0
            };

            _modbusHelper.WriteSingleRegister(slaveAddress, coilAddress, value);
        }

        // 写入 AC 温度
        private void WriteACTemprature(int parameter)
        {
            if (_modbusHelper == null)
            {
                MessageBox.Show("串口未打开或已断开，请检查连接！");
                return;
            }

            byte slaveAddress = 1;
            ushort coilAddress = 1;
            ushort value = (ushort)parameter;

            _modbusHelper.WriteSingleRegister(slaveAddress, coilAddress, value);
        }
    }
}
