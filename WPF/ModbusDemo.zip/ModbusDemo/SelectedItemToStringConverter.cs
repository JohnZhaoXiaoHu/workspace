﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace ModbusDemo
{
    public class SelectedItemToStringConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null)
                return string.Empty;

            // 如果值是整数（例如波特率或数据位），直接转换为字符串
            if (value is int intValue)
            {
                return intValue.ToString();
            }

            // 如果值是枚举类型（如 Parity 或 StopBits），获取枚举的名称
            if (value is Enum enumValue)
            {
                return enumValue.ToString();
            }

            // 默认返回空字符串
            return string.Empty;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null || string.IsNullOrEmpty(value.ToString()))
                return null;

            // 处理整数类型（如波特率或数据位）
            if (targetType == typeof(int))
            {
                if (int.TryParse(value.ToString(), out int result))
                {
                    return result;
                }
            }

            // 处理枚举类型（如 Parity 或 StopBits）
            if (targetType.IsEnum)
            {
                try
                {
                    return Enum.Parse(targetType, value.ToString());
                }
                catch
                {
                    return null;
                }
            }

            // 如果无法转换，返回 null
            return null;
        }
    }
}
