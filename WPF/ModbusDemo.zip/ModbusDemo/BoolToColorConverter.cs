﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Media;

namespace ModbusDemo
{
    public class BoolToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // 判断布尔值并返回相应的颜色
            if (value is bool boolValue)
            {
                return boolValue ? Brushes.White : Brushes.Gray;
            }

            return Brushes.Gray;  // 默认颜色
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // 不需要反向转换
            throw new NotImplementedException();
        }
    }
}
