﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace ModbusDemo
{
    class CloudyToTextConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is ushort cloudyValue)
            {
                // 根据 Cloudy 的值返回相应的文本
                switch (cloudyValue)
                {
                    case 1:
                        return "多云";
                    case 2:
                        return "晴天";
                    case 3:
                        return "小雨";
                    case 4:
                        return "中雨";
                    case 5:
                        return "大雨";
                    default:
                        return "未知天气";
                }
            }
            return "未知天气";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // 如果需要支持双向绑定，可以实现此方法
            throw new NotImplementedException();
        }
    }
}
