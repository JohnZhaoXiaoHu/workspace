﻿using System;
using System.IO;
using System.IO.Ports;
using System.Windows;
using Modbus.Device;

namespace ModbusDemo
{
    public class ModbusRTUHelper : IDisposable
    {
        private SerialPort _serialPort;
        private IModbusMaster _master;
        private bool _isOpen = false;

        // 构造函数，初始化串口连接
        public ModbusRTUHelper(string portName, int baudRate = 19200, int dataBits = 8, Parity parity = Parity.None, StopBits stopBits = StopBits.One)
        {
            _serialPort = new SerialPort(portName, baudRate, parity, dataBits, stopBits);
        }

        // 打开串口连接
        public bool Open()
        {
            try
            {
                if (_serialPort.IsOpen)
                {
                    return false;
                }

                _serialPort.Open();
                _master = ModbusSerialMaster.CreateRtu(_serialPort);
                _isOpen = true;
                return true;
            }
            catch (UnauthorizedAccessException)
            {
                MessageBox.Show("无法访问串口，可能串口被其他程序占用。");
                return false;
            }
            catch (IOException ex)
            {
                MessageBox.Show("串口连接错误: " + ex.Message);
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("打开串口时发生未知错误: " + ex.Message);
                return false;
            }
        }

        // 关闭串口连接
        public void Close()
        {
            try
            {
                if (_serialPort.IsOpen)
                {
                    _serialPort.Close();
                    MessageBox.Show("串口已关闭！");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("关闭串口时发生错误: " + ex.Message);
            }
        }

        // 检查是否连接
        public void CheckConnection()
        {
            if (_master == null || !_isOpen)
            {
                throw new InvalidOperationException("串口未打开或已断开，请检查连接！");
            }
        }

        // 读取线圈状态
        public bool[] ReadCoils(byte slaveAddress, ushort startAddress, ushort numberOfPoints)
        {
            try
            {
                CheckConnection();
                return _master.ReadCoils(slaveAddress, startAddress, numberOfPoints);
            }
            catch (Modbus.SlaveException ex)
            {
                HandleModbusException(ex);
                return null;
            }
            catch (TimeoutException)
            {
                MessageBox.Show("读取操作超时，请检查从设备状态！");
                return null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("发生错误: " + ex.Message);
                return null;
            }
        }

        // 读取输入状态
        public bool[] ReadInputs(byte slaveAddress, ushort startAddress, ushort numberOfPoints)
        {
            try
            {
                CheckConnection();
                return _master.ReadInputs(slaveAddress, startAddress, numberOfPoints);
            }
            catch (Modbus.SlaveException ex)
            {
                HandleModbusException(ex);
                return null;
            }
            catch (TimeoutException)
            {
                MessageBox.Show("读取操作超时，请检查从设备状态！");
                return null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("发生错误: " + ex.Message);
                return null;
            }
        }

        // 读取保持寄存器
        public ushort[] ReadHoldingRegisters(byte slaveAddress, ushort startAddress, ushort numberOfPoints)
        {
            try
            {
                CheckConnection();
                return _master.ReadHoldingRegisters(slaveAddress, startAddress, numberOfPoints);
            }
            catch (Modbus.SlaveException ex)
            {
                HandleModbusException(ex);
                return null;
            }
            catch (TimeoutException)
            {
                MessageBox.Show("读取操作超时，请检查从设备状态！");
                return null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("发生错误: " + ex.Message);
                return null;
            }
        }

        // 读取输入寄存器
        public ushort[] ReadInputRegisters(byte slaveAddress, ushort startAddress, ushort numberOfPoints)
        {
            try
            {
                CheckConnection();
                return _master.ReadInputRegisters(slaveAddress, startAddress, numberOfPoints);
            }
            catch (Modbus.SlaveException ex)
            {
                HandleModbusException(ex);
                return null;
            }
            catch (TimeoutException)
            {
                MessageBox.Show("读取操作超时，请检查从设备状态！");
                return null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("发生错误: " + ex.Message);
                return null;
            }
        }

        // 写单个线圈
        public void WriteSingleCoil(byte slaveAddress, ushort coilAddress, bool value)
        {
            try
            {
                CheckConnection();
                _master.WriteSingleCoil(slaveAddress, coilAddress, value);
            }
            catch (Modbus.SlaveException ex)
            {
                HandleModbusException(ex);
            }
            catch (Exception ex)
            {
                MessageBox.Show("发生错误: " + ex.Message);
            }
        }

        // 写多个线圈
        public void WriteMultipleCoils(byte slaveAddress, ushort coilAddress, bool[] data)
        {
            try
            {
                CheckConnection();
                _master.WriteMultipleCoils(slaveAddress, coilAddress, data);
            }
            catch (Modbus.SlaveException ex)
            {
                HandleModbusException(ex);
            }
            catch (Exception ex)
            {
                MessageBox.Show("发生错误: " + ex.Message);
            }
        }

        // 写单个寄存器
        public void WriteSingleRegister(byte slaveAddress, ushort registerAddress, ushort value)
        {
            try
            {
                CheckConnection();
                _master.WriteSingleRegister(slaveAddress, registerAddress, value);
            }
            catch (Modbus.SlaveException ex)
            {
                HandleModbusException(ex);
            }
            catch (Exception ex)
            {
                MessageBox.Show("发生错误: " + ex.Message);
            }
        }

        // 写多个寄存器
        public void WriteMultipleRegisters(byte slaveAddress, ushort startAddress, ushort[] data)
        {
            try
            {
                CheckConnection();
                _master.WriteMultipleRegisters(slaveAddress, startAddress, data);
            }
            catch (Modbus.SlaveException ex)
            {
                HandleModbusException(ex);
            }
            catch (Exception ex)
            {
                MessageBox.Show("发生错误: " + ex.Message);
            }
        }

        // 处理 Modbus 错误
        private void HandleModbusException(Modbus.SlaveException ex)
        {
            switch (ex.SlaveExceptionCode)
            {
                case 1:
                    MessageBox.Show("异常代码 1: 非法功能码！");
                    break;
                case 2:
                    MessageBox.Show("异常代码 2: 非法数据地址！");
                    break;
                case 3:
                    MessageBox.Show("异常代码 3: 非法数据值！");
                    break;
                case 4:
                    MessageBox.Show("异常代码 4: 从设备故障！");
                    break;
                case 5:
                    MessageBox.Show("异常代码 5: 硬件故障！");
                    break;
                case 6:
                    MessageBox.Show("异常代码 6: 从设备忙！");
                    break;
                case 7:
                    MessageBox.Show("异常代码 7: 内存错误！");
                    break;
                default:
                    MessageBox.Show("未知异常代码: " + ex.SlaveExceptionCode);
                    break;
            }
        }

        // 释放资源
        public void Dispose()
        {
            try
            {
                // 释放资源
                _master?.Dispose();
                if (_serialPort != null)
                {
                    if (_serialPort.IsOpen)
                    {
                        _serialPort.Close();
                    }
                    _serialPort.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("释放资源时发生错误: " + ex.Message);
            }
        }
    }
}
