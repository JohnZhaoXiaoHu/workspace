﻿using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO.Ports;
using System.Linq;
using System.Windows.Data;

namespace ModbusDemo
{
    // 通用转换器：将不同类型的枚举或整数集合转换为字符串集合
    public class IntToStringConverter : IValueConverter
    {
        // 通用转换方法：将集合中的每个项转换为字符串
        private ObservableCollection<string> ConvertCollection<T>(ObservableCollection<T> collection)
        {
            ObservableCollection<string> stringCollection = new ObservableCollection<string>();
            foreach (var item in collection)
            {
                stringCollection.Add(item.ToString());
            }
            return stringCollection;
        }

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // 如果是 ObservableCollection<int>，将其转换为 ObservableCollection<string>
            if (value is ObservableCollection<int> intCollection)
            {
                return ConvertCollection(intCollection);
            }

            // 如果是 ObservableCollection<Parity>，将其转换为 ObservableCollection<string>
            if (value is ObservableCollection<Parity> parityCollection)
            {
                return ConvertCollection(parityCollection);
            }

            // 如果是 ObservableCollection<StopBits>，将其转换为 ObservableCollection<string>
            if (value is ObservableCollection<StopBits> stopBitsCollection)
            {
                return ConvertCollection(stopBitsCollection);
            }

            // 如果输入不是我们处理的类型，返回 null 或者抛出异常
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // 如果需要双向绑定，可以实现 ConvertBack 方法
            throw new NotImplementedException();
        }
    }
}
