﻿namespace H.App.FileManager
{
    public interface IFileToEntityService
    {
        fm_dd_file ToEntity(string file);
    }
}
