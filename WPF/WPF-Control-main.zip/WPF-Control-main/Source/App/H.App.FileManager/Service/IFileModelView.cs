﻿namespace H.App.FileManager
{
    public interface IFileView
    {
        string Description { get; set; }
    }
}