﻿namespace H.App.FileManager
{
    public interface IFileToMoreViewService
    {
        object ToView(fm_dd_file file);
    }
}
