﻿namespace H.App.FileManager
{
    public enum ViewSizeMode
    {
        Normal,
        Auto,
        ExtraLarge,
        Large,
        Small,
        ExtraSmall
    }
}
