﻿namespace H.App.FileManager
{
    public enum DisplayMode
    {
        DataGrid,
        ListBox,
        View
    }
}
