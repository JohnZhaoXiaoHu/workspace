﻿namespace H.App.FileManager
{


    public class ImageView : FileView<fm_dd_image>
    {
        public ImageView(fm_dd_image t) : base(t)
        {
        }
    }
}
