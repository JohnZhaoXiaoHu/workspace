﻿namespace H.App.FileManager
{
    public class MoreFileView : MoreFileViewBase
    {
        public MoreFileView(fm_dd_file t) : base(t)
        {

        }
    }
}
