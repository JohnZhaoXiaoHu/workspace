﻿namespace H.Common.Transitionable;

public interface ITransitionHostable
{
    public ITransitionable Transitionable { get; set; }
}
