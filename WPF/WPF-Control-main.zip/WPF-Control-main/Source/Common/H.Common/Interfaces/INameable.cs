﻿namespace H.Common.Interfaces;

public interface INameable
{

    public string Name { get; set; }
}
