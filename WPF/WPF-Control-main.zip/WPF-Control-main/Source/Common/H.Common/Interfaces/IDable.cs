﻿namespace H.Common.Interfaces;

public interface IDable
{
    string ID { get; set; }
}
