﻿namespace H.Common.Interfaces;

public interface IClearable
{
    void Clear();

}
