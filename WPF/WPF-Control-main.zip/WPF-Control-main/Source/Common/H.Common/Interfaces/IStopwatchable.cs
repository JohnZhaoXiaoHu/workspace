﻿namespace H.Common.Interfaces;

public interface IStopwatchable
{
    public TimeSpan TimeSpan { get; set; }
}
