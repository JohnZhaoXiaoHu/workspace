﻿namespace H.Common.Interfaces;

public interface IDescriptionable
{
    string Description { get; set; }
}
