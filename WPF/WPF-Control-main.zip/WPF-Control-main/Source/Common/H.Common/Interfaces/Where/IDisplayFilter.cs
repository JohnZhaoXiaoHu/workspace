﻿namespace H.Common.Interfaces.Where;

public interface IDisplayFilter : IFilterable, IDisplayable
{

}
