﻿namespace H.Common.Interfaces.Where;

public interface IFilterable
{
    bool IsMatch(object obj);
}
