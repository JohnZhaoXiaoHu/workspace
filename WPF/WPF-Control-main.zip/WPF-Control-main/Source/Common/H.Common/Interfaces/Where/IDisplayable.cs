﻿namespace H.Common.Interfaces.Where;

public interface IDisplayable
{
    string DisplayName { get; }
}
