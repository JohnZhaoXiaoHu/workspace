﻿namespace H.Common.Interfaces.Where;

public interface IOrderWhereable : IWhereable
{

}
