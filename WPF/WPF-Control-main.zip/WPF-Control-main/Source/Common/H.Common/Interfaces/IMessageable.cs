﻿namespace H.Common.Interfaces;

public interface IMessageable
{
    public string Message { get; set; }
}
