﻿namespace H.Common.Interfaces;

public interface IIconable
{
    public string Icon { get; set; }
}
