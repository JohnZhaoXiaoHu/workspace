﻿namespace H.Common.Interfaces;

public interface ITextable
{
    string Text { get; set; }
}
