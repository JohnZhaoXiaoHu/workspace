﻿namespace H.Common.Interfaces;

public interface IOrderable
{
    int Order { get; set; }
}
