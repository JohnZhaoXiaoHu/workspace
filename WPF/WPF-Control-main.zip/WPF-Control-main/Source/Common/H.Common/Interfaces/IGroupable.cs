﻿namespace H.Common.Interfaces;

public interface IGroupable
{

    public string GroupName { get; set; }
}
