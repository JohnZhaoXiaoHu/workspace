﻿namespace H.Common.Interfaces;
public interface IDefaultable
{
    void LoadDefault();
}
