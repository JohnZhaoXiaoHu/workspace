﻿namespace H.Common.Attributes;

public class IDAttribute : Attribute
{
    public string ID { get; set; }
}
