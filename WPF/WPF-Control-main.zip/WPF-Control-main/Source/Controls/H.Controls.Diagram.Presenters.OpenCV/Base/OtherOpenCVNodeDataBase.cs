﻿namespace H.Controls.Diagram.Presenters.OpenCV.Base;
[Icon(FontIcons.More)]
public abstract class OtherOpenCVNodeDataBase : OpenCVNodeDataBase, IOtherOpenCVNodeData
{

}
