﻿namespace H.Controls.Diagram.Presenters.OpenCV.Base;

[Icon(FontIcons.Favicon2)]
public abstract class YolovOpenCVNodeDataBase : OpenCVNodeDataBase, IYolovOpenCVNodeData
{
    public int MyProperty { get; set; }
}