﻿namespace H.Controls.Diagram.Presenters.OpenCV.Base;
[Icon("\xE790")]
public abstract class BasicOpenCVNodeDataBase : OpenCVNodeDataBase, IBasicOpenCVNodeData
{

}
