﻿namespace H.Controls.Diagram.Presenters.OpenCV.Base;

public interface ISrcFilePathableStartNodeData : ISrcFilePathable, IFlowableNodeData
{

}
