﻿namespace H.Controls.Diagram.Presenters.OpenCV.Base;

public interface ISrcFilePathable
{
    string SrcFilePath { get; set; }
}
