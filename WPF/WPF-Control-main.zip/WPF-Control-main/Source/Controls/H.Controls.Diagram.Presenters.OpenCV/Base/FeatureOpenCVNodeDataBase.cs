﻿global using H.Extensions.FontIcon;
global using H.Common.Attributes;

namespace H.Controls.Diagram.Presenters.OpenCV.Base;
[Icon(FontIcons.FitPage)]
public abstract class FeatureOpenCVNodeDataBase : OpenCVNodeDataBase, IFeatureDetectorOpenCVNodeData
{

}
