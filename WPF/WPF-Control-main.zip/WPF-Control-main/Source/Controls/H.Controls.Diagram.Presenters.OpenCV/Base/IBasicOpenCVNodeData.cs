﻿global using H.Mvvm.ViewModels;

namespace H.Controls.Diagram.Presenters.OpenCV.Base;
internal interface IBasicOpenCVNodeData : INodeData, IDisplayBindable
{
}
