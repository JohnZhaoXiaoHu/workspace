﻿namespace H.Controls.Diagram.Presenters.OpenCV.Base;

public interface IFeatureDetectorOpenCVNodeData : INodeData, IDisplayBindable
{

}
