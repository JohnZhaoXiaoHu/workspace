﻿namespace H.Controls.Diagram.Presenters.OpenCV.Base;
public interface IMorphologyOpenCVNodeData : INodeData, IDisplayBindable
{

}
