﻿namespace H.Controls.Diagram.Presenters.OpenCV.Base;

public interface IOtherOpenCVNodeData : INodeData, IDisplayBindable
{

}
