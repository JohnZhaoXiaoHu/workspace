﻿namespace H.Controls.Diagram.Presenters.OpenCV.Base;
[Icon(FontIcons.Filter)]
public abstract class FilterOpenCVNodeDataBase : OpenCVNodeDataBase, IFilterOpenCVNodeData
{

}
