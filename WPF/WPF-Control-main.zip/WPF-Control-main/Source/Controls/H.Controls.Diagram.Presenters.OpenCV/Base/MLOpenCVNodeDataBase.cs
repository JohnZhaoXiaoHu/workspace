﻿namespace H.Controls.Diagram.Presenters.OpenCV.Base;

[Icon(FontIcons.DialShape1)]
public abstract class MLOpenCVNodeDataBase : OpenCVNodeDataBase, IMLOpenCVNodeData
{

}
