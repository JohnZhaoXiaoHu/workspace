﻿using H.Common.Interfaces;

namespace H.Controls.Diagram.Presenters.OpenCV.Base;

public interface IVideoNodeData : INodeData, IOrderable
{

}

