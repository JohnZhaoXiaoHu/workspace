﻿namespace H.Controls.Diagram.Presenters.OpenCV.NodeDatas.Filter;
public interface IFilterOpenCVNodeData : INodeData, IDisplayBindable
{

}
