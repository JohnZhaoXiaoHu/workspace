﻿namespace H.Controls.Diagram.Presenters.OpenCV.NodeDataGroups;

public abstract class VideoDataGroupBase : NodeDataGroupBase, IVideoDataGroup
{

}
