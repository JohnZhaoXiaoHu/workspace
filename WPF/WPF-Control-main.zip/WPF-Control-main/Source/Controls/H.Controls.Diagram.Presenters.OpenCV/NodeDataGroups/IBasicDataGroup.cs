﻿namespace H.Controls.Diagram.Presenters.OpenCV.NodeDataGroups;

public interface IBasicDataGroup : INodeDataGroup
{

}
