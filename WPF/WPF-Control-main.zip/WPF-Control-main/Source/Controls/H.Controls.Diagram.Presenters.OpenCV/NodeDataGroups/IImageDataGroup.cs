﻿namespace H.Controls.Diagram.Presenters.OpenCV.NodeDataGroups;

public interface IImageDataGroup : INodeDataGroup
{

}
