﻿namespace H.Controls.Diagram.Presenters.OpenCV.NodeDataGroups;

public interface IVideoDataGroup : INodeDataGroup
{

}
