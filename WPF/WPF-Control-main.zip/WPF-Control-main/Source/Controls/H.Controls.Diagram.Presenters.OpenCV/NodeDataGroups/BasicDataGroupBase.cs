﻿namespace H.Controls.Diagram.Presenters.OpenCV.NodeDataGroups;

public abstract class BasicDataGroupBase : NodeDataGroupBase, IBasicDataGroup
{

}
