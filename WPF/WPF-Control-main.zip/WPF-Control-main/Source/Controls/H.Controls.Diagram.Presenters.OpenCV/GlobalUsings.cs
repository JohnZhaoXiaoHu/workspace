﻿global using OpenCvSharp;
global using OpenCvSharp.WpfExtensions;
global using System;
global using System.ComponentModel;
global using System.ComponentModel.DataAnnotations;
global using System.Linq;

