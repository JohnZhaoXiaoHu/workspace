﻿namespace H.Controls.ColorPicker.Models
{
    public enum PickerType
    {
        HSV = 0,
        HSL = 1
    }
}