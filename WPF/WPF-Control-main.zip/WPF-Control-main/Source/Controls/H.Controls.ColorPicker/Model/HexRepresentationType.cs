﻿namespace H.Controls.ColorPicker.Models
{
    public enum HexRepresentationType
    {
        RGBA,
        ARGB
    }
}