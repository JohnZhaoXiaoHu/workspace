﻿namespace H.Controls.ColorPicker.Models
{
    public interface ISecondColorStorage
    {
        ColorState SecondColorState { get; set; }
    }
}