﻿namespace H.Controls.ColorPicker.Models
{
    public interface IHintColorStateStorage
    {
        ColorState HintColorState { get; set; }
    }
}