﻿namespace H.Controls.ColorPicker.Models
{
    public interface IColorStateStorage
    {
        ColorState ColorState { get; set; }
    }
}