﻿// Copyright © 2024 By HeBianGu(QQ:908293466) https://github.com/HeBianGu/WPF-Control
namespace H.Controls.Adorner.Draggable;

public enum DraggableAdornerMode
{
    Both = 0,
    OnlyX,
    OnlyY,
}
