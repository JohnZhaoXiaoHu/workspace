﻿namespace H.Controls.Diagram.Presenter.Flowables;

public enum DiagramFlowableZoomMode
{
    None = 0,
    Rect,
    Center
}
