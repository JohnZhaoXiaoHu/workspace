﻿namespace H.Controls.Diagram.Presenter.Flowables;

public enum DiagramFlowableMode
{
    Node = 0,
    Link,
    Port
}
