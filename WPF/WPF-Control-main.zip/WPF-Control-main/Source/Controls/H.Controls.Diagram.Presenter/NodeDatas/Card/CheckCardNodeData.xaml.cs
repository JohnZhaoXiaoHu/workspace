﻿namespace H.Controls.Diagram.Presenter.NodeDatas.Card;

public class CheckCardNodeData : CardNodeData
{

}
