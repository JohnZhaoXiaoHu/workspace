﻿namespace H.Controls.Diagram.Presenter.NodeDatas;

public class PropertyNodeData : FlowableNodeData
{

}
