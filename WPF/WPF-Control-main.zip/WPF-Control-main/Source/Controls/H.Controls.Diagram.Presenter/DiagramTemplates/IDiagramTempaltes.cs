﻿namespace H.Controls.Diagram.Presenter.DiagramTemplates;

public interface IDiagramTempaltes
{
    ObservableCollection<IDiagramTemplate> Collection { get; set; }
}
