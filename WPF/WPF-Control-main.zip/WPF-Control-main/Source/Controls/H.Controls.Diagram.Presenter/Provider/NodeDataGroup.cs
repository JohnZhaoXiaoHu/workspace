﻿namespace H.Controls.Diagram.Presenter.Provider;

public class NodeDataGroup : NodeDataGroupBase
{
    protected override IEnumerable<INodeData> CreateNodeDatas()
    {
        return Enumerable.Empty<INodeData>();
    }
}
