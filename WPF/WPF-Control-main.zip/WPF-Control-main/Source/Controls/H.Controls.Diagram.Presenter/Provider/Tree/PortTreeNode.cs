﻿namespace H.Controls.Diagram.Presenter.Provider.Tree;

public class PortTreeNode : PartTreeNodeBase
{
    public PortTreeNode(Port model) : base(model)
    {

    }
}
