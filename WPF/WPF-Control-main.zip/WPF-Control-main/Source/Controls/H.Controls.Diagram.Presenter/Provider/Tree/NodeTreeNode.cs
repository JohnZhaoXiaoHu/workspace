﻿namespace H.Controls.Diagram.Presenter.Provider.Tree;

public class NodeTreeNode : PartTreeNodeBase
{
    public NodeTreeNode(Node model) : base(model)
    {

    }
}
