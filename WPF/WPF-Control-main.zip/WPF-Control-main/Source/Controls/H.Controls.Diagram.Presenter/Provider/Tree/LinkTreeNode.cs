﻿namespace H.Controls.Diagram.Presenter.Provider.Tree;

public class LinkTreeNode : PartTreeNodeBase
{
    public LinkTreeNode(Link model) : base(model)
    {

    }
}
