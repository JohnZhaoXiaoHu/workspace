﻿namespace H.Controls.Diagram.Presenter.Provider;

public class DiagramThemeGroup : ObservableCollection<DiagramTheme>
{

}
