﻿
namespace H.Controls.Diagram.Presenter.DiagramDatas.Base;

public interface IZoomableDiagramData
{
    //void PanToCenter();
    //void PanTo(Part part);
    //void ZoomTo(Part part);
    //void ZoomToFit();
    //void ZoomTo(Point point);
}