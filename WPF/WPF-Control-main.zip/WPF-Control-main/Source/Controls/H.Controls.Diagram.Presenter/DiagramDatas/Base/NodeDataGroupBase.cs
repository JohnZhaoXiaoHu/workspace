﻿global using H.Mvvm.ViewModels.Base;

namespace H.Controls.Diagram.Presenter.DiagramDatas.Base;

[Icon("\xE722")]
public abstract class NodeDataGroupBase : GroupDisplayBindableBase<INodeData>, INodeDataGroup
{

}
