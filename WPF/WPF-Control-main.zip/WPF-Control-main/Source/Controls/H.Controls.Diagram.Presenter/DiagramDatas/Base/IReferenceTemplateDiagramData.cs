﻿namespace H.Controls.Diagram.Presenter.DiagramDatas.Base;

public interface IReferenceTemplateDiagramData
{
    ObservableCollection<FlowableDiagramTemplateNodeData> ReferenceTemplateNodeDatas { get; set; }
}
