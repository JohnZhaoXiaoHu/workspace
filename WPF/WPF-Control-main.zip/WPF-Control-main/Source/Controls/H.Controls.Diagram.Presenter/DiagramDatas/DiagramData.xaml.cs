﻿namespace H.Controls.Diagram.Presenter.DiagramDatas;

//public class NodeGroupsDiagramDataKeys
//{
//    //public static ComponentResourceKey NodeGroupItemsControl => new ComponentResourceKey(typeof(NodeGroupsDiagramDataKeys), "S.NodeGroupsDiagramData.NodeGroups.ItemsControl");

//    public static ComponentResourceKey NodeGroupPopup => new ComponentResourceKey(typeof(NodeGroupsDiagramDataKeys), "S.NodeGroupsDiagramData.NodeGroups.Popup");
//}

