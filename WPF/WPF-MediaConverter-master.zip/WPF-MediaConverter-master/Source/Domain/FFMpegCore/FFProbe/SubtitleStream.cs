﻿namespace FFMpegCore
{
    public class SubtitleStream : MediaStream
    {

    }
}
