﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("FFMpegCore.Test")]
