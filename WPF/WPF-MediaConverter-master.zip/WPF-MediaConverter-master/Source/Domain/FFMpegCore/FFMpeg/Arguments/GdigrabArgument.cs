﻿namespace FFMpegCore.Arguments
{
    public class GdigrabArgument : IArgument
    { 
        public string Text => $"-f gdigrab";
    }
    
}
