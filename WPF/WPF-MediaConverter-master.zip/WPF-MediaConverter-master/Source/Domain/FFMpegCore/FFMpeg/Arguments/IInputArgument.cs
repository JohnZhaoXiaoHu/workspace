﻿namespace FFMpegCore.Arguments
{
    public interface IInputArgument : IInputOutputArgument
    {
    }
}
