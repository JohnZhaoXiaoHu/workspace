﻿namespace FFMpegCore.Arguments
{
    public interface IOutputArgument : IInputOutputArgument
    {
    }
}
