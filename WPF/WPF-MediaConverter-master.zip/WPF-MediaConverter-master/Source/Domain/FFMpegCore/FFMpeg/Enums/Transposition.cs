﻿namespace FFMpegCore.Enums
{
    public enum Transposition
    {
        CounterClockwise90VerticalFlip = 0,
        Clockwise90 = 1,
        CounterClockwise90 = 2,
        Clockwise90VerticalFlip = 3
    }
}
