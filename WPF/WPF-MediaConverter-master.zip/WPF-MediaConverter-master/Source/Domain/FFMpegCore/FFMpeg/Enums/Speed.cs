﻿namespace FFMpegCore.Enums
{
    public enum Speed
    {
        VerySlow,
        Slower,
        Slow,
        Medium,
        Fast,
        Faster,
        VeryFast,
        SuperFast,
        UltraFast
    }
}
