﻿namespace FFMpegCore.Enums
{
    public enum HardwareAccelerationDevice
    {
        Auto,
        D3D11VA,
        DXVA2,
        QSV,
        CUVID,
        CUDA,
        VDPAU,
        VAAPI,
        LibMFX
    }
}
