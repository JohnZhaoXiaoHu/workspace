﻿namespace FFMpegCore.Enums
{
    public enum Mirroring
    {
        Vertical,
        Horizontal
    }
}
