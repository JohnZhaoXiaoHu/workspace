WPF-MediaConverter H视频转换器

视频格式转换工具

软件支持音频转换、视频转换、视频压缩、视频编辑、合并转换等多种功能

## 启动页面
![qrcode](https://raw.githubusercontent.com/HeBianGu/WPF-MediaConverter/master/Document/1.png)
## 视频转换
![qrcode](https://raw.githubusercontent.com/HeBianGu/WPF-MediaConverter/master/Document/2.png)
## Gif转换
![qrcode](https://raw.githubusercontent.com/HeBianGu/WPF-MediaConverter/master/Document/3.png)
## 章节设置
![qrcode](https://raw.githubusercontent.com/HeBianGu/WPF-MediaConverter/master/Document/4.png)
## 关于页面
![qrcode](https://raw.githubusercontent.com/HeBianGu/WPF-MediaConverter/master/Document/5.png)
## 设置页面
![qrcode](https://raw.githubusercontent.com/HeBianGu/WPF-MediaConverter/master/Document/6.png)
## 新手向导
![qrcode](https://raw.githubusercontent.com/HeBianGu/WPF-MediaConverter/master/Document/7.png)
## 主题设置
![qrcode](https://raw.githubusercontent.com/HeBianGu/WPF-MediaConverter/master/Document/8.png)

## 视频预览
https://www.bilibili.com/video/BV1m24y1L7Va

## 推荐学习官方文档
https://learn.microsoft.com/zh-cn/dotnet/api/system.windows.controls?view=windowsdesktop-8.0?wt.mc_id=MVP_380318
## 推荐查看在线源码
https://referencesource.microsoft.com/?wt.mc_id=MVP_380318
