﻿using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MachineVision.Core.TeamplateMatch
{
    public class BaseParamter:BindableBase
    {
        /// <summary>
        /// 初始化参数值
        /// </summary>
        public virtual void InitParamterValue()
        {

        }
    }
}
