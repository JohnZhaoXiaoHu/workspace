﻿namespace FirstDraft.ApplyDemo.WXWork
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : FdWindow
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
