﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FirstDraft.ApplyDemo.ViewModels
{
    class ApplyTextBoxViewModel
    {
    }
}
