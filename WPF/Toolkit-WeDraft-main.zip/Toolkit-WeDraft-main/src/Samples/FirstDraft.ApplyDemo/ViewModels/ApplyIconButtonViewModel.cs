namespace FirstDraft.ApplyDemo.ViewModels
{
    internal class ApplyIconButtonViewModel
    {
    }
}
