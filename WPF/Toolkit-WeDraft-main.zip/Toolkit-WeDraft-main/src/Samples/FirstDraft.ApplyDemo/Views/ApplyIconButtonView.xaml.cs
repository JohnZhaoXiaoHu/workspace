using System.Windows.Controls;

namespace FirstDraft.ApplyDemo.Views
{
    /// <summary>
    /// Interaction logic for IconButtonView.xaml
    /// </summary>
    public partial class ApplyIconButtonView : UserControl
    {
        public ApplyIconButtonView()
        {
            InitializeComponent();
        }
    }
}
