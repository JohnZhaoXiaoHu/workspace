﻿using AutoNodeVision.Plugin.PluginAttribute;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoNodeVision.Plugin.Service.ImageAcquisition
{
    [Category("相机采集")]
    [DisplayName("大华相机采集")]
    [Icon("CameraMarker")]
    public class DHImageAcquisition:BasePluginService
    {


       
    }
}
