﻿using AutoNodeVision.Plugin.PluginAttribute;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoNodeVision.Plugin.Service.Morphology
{
    [Category("形态学处理")]
    [DisplayName("区域膨胀")]
    [Icon("Shape")]
    public class DilationHandle:BasePluginService
    {
    }
}
