﻿using AutoNodeVision.Plugin.PluginAttribute;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoNodeVision.Plugin.Service.TemplateProcessing
{
    [Category("模板处理工具箱")]
    [DisplayName("匹配模板")]
    [Icon("WindowShutterCog")]
    public class FindTemplateService:BasePluginService
    {
    }
}
