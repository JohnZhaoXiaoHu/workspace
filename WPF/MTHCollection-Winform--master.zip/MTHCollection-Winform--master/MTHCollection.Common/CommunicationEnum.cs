﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTHCollection.Common
{
    public enum NetType
    {
        MC,
        ModbusTcp,
        基恩士上位链路,
    }

    public enum SerialType
    {
        ModbusRtu,
        FxSerial,
    }
}
