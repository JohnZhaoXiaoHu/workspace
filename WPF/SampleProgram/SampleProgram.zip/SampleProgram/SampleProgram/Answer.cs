﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SampleProgram
{

    public class ComplexGame
    {

        public void Setup()
        {
            // TODO: Set up the state of the game here
        }

        public void Play(int moves)
        {
            // TODO: Play the game moves here
        }
    }

}
