﻿namespace SampleProgram.Test
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class TestAnswerFixture
    {
        // TODO: add additional tests for your answer
    }
}
