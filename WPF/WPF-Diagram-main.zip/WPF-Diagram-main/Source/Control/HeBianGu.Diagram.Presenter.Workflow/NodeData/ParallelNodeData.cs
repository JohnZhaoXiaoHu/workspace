﻿namespace HeBianGu.Diagram.Presenter.Workflow
{
    //[NodeType(Type = DiagramType.Workflow, Name = "并行模式", GroupName = "基本流程图形状", Order = 0, Description = "并行模式")]
    //public class ParallelNodeData : WorkflowNodeBase
    //{
    //    public ParallelNodeData()
    //    {
    //        this.Stretch = Stretch.Uniform;
    //    }
    //    protected override Geometry GetGeometry()
    //    {
    //        GeometryConverter converter = new GeometryConverter();
    //        return converter.ConvertFromString("F1M0,20 L0,20 100,20Z M0,40 L0,40 100,40Z") as Geometry;
    //    }
    //}
}
