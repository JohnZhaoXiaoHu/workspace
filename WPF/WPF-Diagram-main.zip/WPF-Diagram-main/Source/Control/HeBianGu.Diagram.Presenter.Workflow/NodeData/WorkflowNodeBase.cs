﻿
namespace HeBianGu.Diagram.Presenter.Workflow
{
    public abstract class WorkflowNodeBase : GeometryNodeDataBase, IWorkflowNode
    {

    }

    public interface IWorkflowNode
    {

    }
}
