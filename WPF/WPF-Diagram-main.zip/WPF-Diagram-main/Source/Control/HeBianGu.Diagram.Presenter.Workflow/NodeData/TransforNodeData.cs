﻿namespace HeBianGu.Diagram.Presenter.Workflow
{
    //[NodeType(Type = DiagramType.Workflow, Name = "控制传递", GroupName = "基本流程图形状", Order = 0, Description = "控制传递")]
    //public class TransforNodeData : WorkflowNodeBase
    //{
    //    public TransforNodeData()
    //    {
    //        this.Stretch = Stretch.Uniform;
    //    }
    //    protected override Geometry GetGeometry()
    //    {
    //        GeometryConverter converter = new GeometryConverter();
    //        return converter.ConvertFromString("F1M0,30 L0,30 40,30Z M45,25 55,30 45,35Z M55,30 L55,30 100,30Z") as Geometry;
    //    }
    //}
}
