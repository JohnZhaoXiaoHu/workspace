﻿
namespace HeBianGu.Diagram.Presenter.Workflow
{
    public abstract class WorkflowBase : FlowableDiagramBase
    {
        //protected override IEnumerable<ILinkDrawer> CreateLinkDrawerSource()
        //{
        //    yield return new BrokenLinkDrawer();
        //}
    }
}
