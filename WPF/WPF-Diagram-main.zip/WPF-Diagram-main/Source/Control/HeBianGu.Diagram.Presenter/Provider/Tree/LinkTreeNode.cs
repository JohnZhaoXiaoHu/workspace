﻿

using HeBianGu.Diagram.DrawingBox;

namespace HeBianGu.Diagram.Presenter
{
    public class LinkTreeNode : PartTreeNodeBase
    {
        public LinkTreeNode(Link model) : base(model)
        {

        }
    }
}
