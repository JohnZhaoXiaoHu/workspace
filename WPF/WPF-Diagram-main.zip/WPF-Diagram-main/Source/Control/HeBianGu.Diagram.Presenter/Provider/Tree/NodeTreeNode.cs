﻿

using HeBianGu.Diagram.DrawingBox;

namespace HeBianGu.Diagram.Presenter
{
    public class NodeTreeNode : PartTreeNodeBase
    {
        public NodeTreeNode(Node model) : base(model)
        {

        }
    }
}
