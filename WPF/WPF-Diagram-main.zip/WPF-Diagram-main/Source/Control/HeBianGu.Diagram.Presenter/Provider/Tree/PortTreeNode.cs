﻿

using HeBianGu.Diagram.DrawingBox;

namespace HeBianGu.Diagram.Presenter
{
    public class PortTreeNode : PartTreeNodeBase
    {
        public PortTreeNode(Port model) : base(model)
        {

        }
    }
}
