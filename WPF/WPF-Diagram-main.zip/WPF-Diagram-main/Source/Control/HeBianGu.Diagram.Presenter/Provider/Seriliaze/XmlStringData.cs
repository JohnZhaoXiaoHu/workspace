﻿namespace HeBianGu.Diagram.Presenter
{
    public class XmlStringData
    {
        public XmlStringData()
        {

        }
        public XmlStringData(string value)
        {
            this.Value = value;
        }
        public string Value { get; set; }
    }
}
