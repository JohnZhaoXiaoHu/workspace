﻿using System.Collections.ObjectModel;

namespace HeBianGu.Diagram.Presenter
{
    public class DiagramThemeGroup : ObservableCollection<DiagramTheme>
    {

    }
}
