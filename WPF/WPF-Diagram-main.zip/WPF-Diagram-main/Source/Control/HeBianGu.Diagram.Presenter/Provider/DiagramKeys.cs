﻿using System.Windows;

namespace HeBianGu.Diagram.Presenter
{
    public class DiagramKeys
    {
        public static ComponentResourceKey TextKey => new ComponentResourceKey(typeof(DiagramKeys), "S.TextBox.Text");
    }
}
