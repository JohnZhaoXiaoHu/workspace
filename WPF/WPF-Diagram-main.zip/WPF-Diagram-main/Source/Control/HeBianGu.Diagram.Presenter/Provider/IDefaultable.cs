﻿namespace HeBianGu.Diagram.Presenter
{
    public interface IDefaultable
    {
        void LoadDefault();
    }
}
