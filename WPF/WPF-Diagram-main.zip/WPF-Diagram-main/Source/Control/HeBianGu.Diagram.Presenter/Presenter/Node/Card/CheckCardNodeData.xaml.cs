﻿namespace HeBianGu.Diagram.Presenter
{
    public class CheckCardNodeData : CardNodeData
    {

    }
}
