﻿namespace HeBianGu.Diagram.Presenter
{
    public class PropertyNodeData : FlowableNodeData
    {

    }
}
