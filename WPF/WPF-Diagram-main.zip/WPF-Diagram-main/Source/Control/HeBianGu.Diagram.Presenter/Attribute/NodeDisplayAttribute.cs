﻿namespace HeBianGu.Diagram.Presenter
{
    //[System.AttributeUsage(AttributeTargets.Class, Inherited = false, AllowMultiple = false)]
    //public class NodeDisplayAttribute : Attribute
    //{
    //    public string Name { get; set; }

    //    public string GroupName { get; set; }

    //    public int Order { get; set; }

    //    public string Description { get; set; }
    //}
}
