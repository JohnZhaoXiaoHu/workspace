﻿namespace HeBianGu.Diagram.Presenter
{
    //public enum DiagramType
    //{
    //    Workflow, AuditWorkflow, Lane
    //}
}
