﻿namespace HeBianGu.Diagram.DrawingBox
{
    public enum DiagramFlowableMode
    {
        Node = 0,
        Link,
        Port
    }
}
