﻿// Copyright © 2024 By HeBianGu(QQ:908293466) https://github.com/HeBianGu/WPF-Control

using System;

namespace HeBianGu.Diagram.DrawingBox
{
    /// <summary> 关系布局 </summary>
    public class ForceDirectedLayout : Layout
    {
        public override void DoLayout(params Node[] nodes)
        {
            throw new NotImplementedException();
        }
    }
}
