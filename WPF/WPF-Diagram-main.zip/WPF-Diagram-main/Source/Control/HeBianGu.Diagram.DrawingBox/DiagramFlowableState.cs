﻿namespace HeBianGu.Diagram.DrawingBox
{
    public enum DiagramFlowableState
    {
        None = 0,
        Running,
        Success,
        Error,
        Stopped,
        Canceling,
        Canceled
    }
}
