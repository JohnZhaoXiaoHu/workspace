﻿namespace HeBianGu.Diagram.DrawingBox
{
    public enum DiagramFlowableZoomMode
    {
        None = 0,
        Rect,
        Center
    }
}
