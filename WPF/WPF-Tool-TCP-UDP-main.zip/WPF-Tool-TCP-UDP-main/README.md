# WPF-Tool
 小工具

## TCP
![qrcode](https://raw.githubusercontent.com/HeBianGu/WPF-Tool/main/SocketTool/Document/1.png)

![qrcode](https://raw.githubusercontent.com/HeBianGu/WPF-Tool/main/SocketTool/Document/2.png)

## UDP
![qrcode](https://raw.githubusercontent.com/HeBianGu/WPF-Tool/main/SocketTool/Document/3.png)

![qrcode](https://raw.githubusercontent.com/HeBianGu/WPF-Tool/main/SocketTool/Document/4.png)


## 推荐学习官方文档
https://learn.microsoft.com/zh-cn/dotnet/api/system.windows.controls?view=windowsdesktop-8.0?wt.mc_id=MVP_380318
## 推荐查看在线源码
https://referencesource.microsoft.com/?wt.mc_id=MVP_380318
