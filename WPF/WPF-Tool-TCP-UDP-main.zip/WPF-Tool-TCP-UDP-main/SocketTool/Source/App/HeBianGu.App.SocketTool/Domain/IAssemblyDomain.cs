﻿namespace HeBianGu.App.SocketTool
{
    public interface IAssemblyDomain
    {

    }
}