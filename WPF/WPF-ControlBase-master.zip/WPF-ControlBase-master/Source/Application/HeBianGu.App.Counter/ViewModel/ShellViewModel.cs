﻿using HeBianGu.Base.WpfBase;
using HeBianGu.Service.AppConfig;
using HeBianGu.Systems.Print;
using HeBianGu.Systems.Project;
using HeBianGu.Systems.WinTool;
using HeBianGu.Systems.XmlSerialize;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Xml.Serialization;

namespace HeBianGu.App.Counter
{
    internal class ShellViewModel : NotifyPropertyChanged
    {

    }
}
