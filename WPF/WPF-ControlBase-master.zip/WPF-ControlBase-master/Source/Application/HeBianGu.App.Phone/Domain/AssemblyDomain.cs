﻿namespace HeBianGu.App.Phone
{
    public class AssemblyDomain : IAssemblyDomain
    {

    }
}
