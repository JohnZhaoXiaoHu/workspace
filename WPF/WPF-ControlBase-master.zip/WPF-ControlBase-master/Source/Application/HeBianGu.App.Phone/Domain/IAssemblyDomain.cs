﻿namespace HeBianGu.App.Phone
{
    public interface IAssemblyDomain
    {

    }
}