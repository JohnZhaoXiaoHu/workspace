﻿using HeBianGu.Service.Mvc;
using System;

namespace HeBianGu.App.Phone
{
    [ViewModel("Custom")]
    internal class CustomViewModel : MvcViewModelBase
    {

        protected override void Init()
        {

        }

        protected override void Loaded(string args)
        {

        }
    }
}
