﻿namespace HeBianGu.App.Above
{
    public class AssemblyDomain : IAssemblyDomain
    {

    }
}
