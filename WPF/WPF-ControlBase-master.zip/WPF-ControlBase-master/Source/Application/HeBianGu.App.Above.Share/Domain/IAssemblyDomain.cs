﻿namespace HeBianGu.App.Above
{
    public interface IAssemblyDomain
    {

    }
}