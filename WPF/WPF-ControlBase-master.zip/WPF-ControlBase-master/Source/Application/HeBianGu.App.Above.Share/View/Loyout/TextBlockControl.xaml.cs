﻿using System.Windows.Controls;

namespace HeBianGu.App.Above.View.Loyout
{
    /// <summary>
    /// TextBlockControl.xaml 的交互逻辑
    /// </summary>
    public partial class TextBlockControl : UserControl
    {
        public TextBlockControl()
        {
            InitializeComponent();
        }
    }
}
