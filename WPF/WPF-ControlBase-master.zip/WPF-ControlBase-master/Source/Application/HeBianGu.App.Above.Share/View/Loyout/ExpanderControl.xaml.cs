﻿using System.Windows.Controls;

namespace HeBianGu.App.Above.View.Loyout
{
    /// <summary>
    /// ExpanderControl.xaml 的交互逻辑
    /// </summary>
    public partial class ExpanderControl : UserControl
    {
        public ExpanderControl()
        {
            InitializeComponent();
        }
    }
}
