﻿using System.Windows.Controls;

namespace HeBianGu.App.Above.View.Loyout
{
    /// <summary>
    /// TabControl.xaml 的交互逻辑
    /// </summary>
    public partial class TabControl : UserControl
    {
        public TabControl()
        {
            InitializeComponent();
        }
    }
}
