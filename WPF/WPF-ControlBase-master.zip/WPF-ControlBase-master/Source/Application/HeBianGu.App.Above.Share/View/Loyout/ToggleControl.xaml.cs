﻿using System.Windows.Controls;

namespace HeBianGu.App.Above.View.Loyout
{
    /// <summary>
    /// ToggleControl.xaml 的交互逻辑
    /// </summary>
    public partial class ToggleControl : UserControl
    {
        public ToggleControl()
        {
            InitializeComponent();
        }
    }
}
