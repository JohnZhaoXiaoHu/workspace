﻿using System.Windows.Controls;

namespace HeBianGu.App.Above.View.Loyout
{
    /// <summary>
    /// TextBoxControl.xaml 的交互逻辑
    /// </summary>
    public partial class TextBoxControl : UserControl
    {
        public TextBoxControl()
        {
            InitializeComponent();
        }
    }
}
