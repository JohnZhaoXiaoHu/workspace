﻿using System.Windows.Controls;

namespace HeBianGu.App.Above.View.Loyout
{
    /// <summary>
    /// ContextMenuControl.xaml 的交互逻辑
    /// </summary>
    public partial class ContextMenuControl : UserControl
    {
        public ContextMenuControl()
        {
            InitializeComponent();
        }
    }
}
