﻿using System.Windows.Controls;

namespace HeBianGu.App.Above.View.Loyout
{
    /// <summary>
    /// CheckBoxControl.xaml 的交互逻辑
    /// </summary>
    public partial class CheckBoxControl : UserControl
    {
        public CheckBoxControl()
        {
            InitializeComponent();
        }
    }
}
