﻿using System.Windows.Controls;

namespace HeBianGu.App.Above.View.Loyout
{
    /// <summary>
    /// ButtonControl.xaml 的交互逻辑
    /// </summary>
    public partial class ButtonControl : UserControl
    {
        public ButtonControl()
        {
            //InitializeComponent();
        }
    }
}
