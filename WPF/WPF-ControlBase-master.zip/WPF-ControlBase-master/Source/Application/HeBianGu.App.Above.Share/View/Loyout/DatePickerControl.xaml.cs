﻿using System.Windows.Controls;

namespace HeBianGu.App.Above.View.Loyout
{
    /// <summary>
    /// DatePickerControl.xaml 的交互逻辑
    /// </summary>
    public partial class DatePickerControl : UserControl
    {
        public DatePickerControl()
        {
            InitializeComponent();
        }
    }
}
