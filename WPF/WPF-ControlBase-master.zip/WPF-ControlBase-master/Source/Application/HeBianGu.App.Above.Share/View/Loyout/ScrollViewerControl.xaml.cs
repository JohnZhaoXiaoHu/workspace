﻿using System.Windows.Controls;

namespace HeBianGu.App.Above.View.Loyout
{
    /// <summary>
    /// ScrollViewerControl.xaml 的交互逻辑
    /// </summary>
    public partial class ScrollViewerControl : UserControl
    {
        public ScrollViewerControl()
        {
            InitializeComponent();
        }
    }
}
