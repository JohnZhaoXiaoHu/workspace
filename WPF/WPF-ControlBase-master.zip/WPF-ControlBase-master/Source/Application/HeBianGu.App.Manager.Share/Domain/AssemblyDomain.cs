﻿namespace HeBianGu.App.Manager
{
    public class AssemblyDomain : IAssemblyDomain
    {

    }
}
