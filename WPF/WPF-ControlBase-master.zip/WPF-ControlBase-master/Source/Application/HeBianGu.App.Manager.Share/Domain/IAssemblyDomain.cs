﻿namespace HeBianGu.App.Manager
{
    public interface IAssemblyDomain
    {

    }
}