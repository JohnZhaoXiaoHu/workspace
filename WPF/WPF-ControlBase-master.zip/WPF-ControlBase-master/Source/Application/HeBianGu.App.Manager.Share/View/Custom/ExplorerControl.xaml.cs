﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Custom
{
    /// <summary>
    /// ExplorerControl.xaml 的交互逻辑
    /// </summary>
    public partial class ExplorerControl : UserControl
    {
        public ExplorerControl()
        {
            InitializeComponent();
        }
    }
}
