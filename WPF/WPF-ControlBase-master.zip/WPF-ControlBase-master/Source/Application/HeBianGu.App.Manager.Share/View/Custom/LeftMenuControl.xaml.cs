﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Custom
{
    /// <summary>
    /// LeftMenuControl.xaml 的交互逻辑
    /// </summary>
    public partial class LeftMenuControl : UserControl
    {
        public LeftMenuControl()
        {
            InitializeComponent();
        }
    }
}
