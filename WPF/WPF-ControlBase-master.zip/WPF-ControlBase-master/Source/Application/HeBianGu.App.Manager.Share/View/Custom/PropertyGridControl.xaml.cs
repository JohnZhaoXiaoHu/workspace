﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Custom
{
    /// <summary>
    /// PropertyGridControl.xaml 的交互逻辑
    /// </summary>
    public partial class PropertyGridControl : UserControl
    {
        public PropertyGridControl()
        {
            InitializeComponent();
        }
    }
}
