﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Custom
{
    /// <summary>
    /// ShuttleControl.xaml 的交互逻辑
    /// </summary>
    public partial class ShuttleControl : UserControl
    {
        public ShuttleControl()
        {
            InitializeComponent();
        }
    }
}
