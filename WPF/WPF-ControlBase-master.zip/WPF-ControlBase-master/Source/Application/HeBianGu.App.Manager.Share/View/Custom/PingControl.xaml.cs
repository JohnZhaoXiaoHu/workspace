﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Custom
{
    /// <summary>
    /// PingControl.xaml 的交互逻辑
    /// </summary>
    public partial class PingControl : UserControl
    {
        public PingControl()
        {
            InitializeComponent();
        }
    }
}
