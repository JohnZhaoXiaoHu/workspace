﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Custom
{
    /// <summary>
    /// ScrollControl.xaml 的交互逻辑
    /// </summary>
    public partial class ScrollControl : UserControl
    {
        public ScrollControl()
        {
            InitializeComponent();
        }
    }
}
