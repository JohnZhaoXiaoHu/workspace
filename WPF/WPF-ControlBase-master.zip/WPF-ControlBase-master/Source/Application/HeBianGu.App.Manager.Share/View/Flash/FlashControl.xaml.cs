﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Wave
{
    /// <summary>
    /// FlashControl.xaml 的交互逻辑
    /// </summary>
    public partial class FlashControl : UserControl
    {
        public FlashControl()
        {
            InitializeComponent();
        }
    }
}
