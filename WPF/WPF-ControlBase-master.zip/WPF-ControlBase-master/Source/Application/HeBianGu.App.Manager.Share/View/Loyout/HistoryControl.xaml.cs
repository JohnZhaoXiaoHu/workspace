﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Loyout
{
    /// <summary>
    /// HistoryControl.xaml 的交互逻辑
    /// </summary>
    public partial class HistoryControl : UserControl
    {
        public HistoryControl()
        {
            InitializeComponent();
        }
    }
}
