﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Loyout
{
    /// <summary>
    /// RealDataControl.xaml 的交互逻辑
    /// </summary>
    public partial class RealDataControl : UserControl
    {
        public RealDataControl()
        {
            InitializeComponent();
        }
    }
}
