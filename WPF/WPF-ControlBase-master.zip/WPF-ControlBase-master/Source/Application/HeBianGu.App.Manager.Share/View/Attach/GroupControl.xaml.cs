﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Attach
{
    /// <summary>
    /// GroupControl.xaml 的交互逻辑
    /// </summary>
    public partial class GroupControl : UserControl
    {
        public GroupControl()
        {
            //InitializeComponent();
        }
    }
}
