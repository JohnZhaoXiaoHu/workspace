﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Attach
{
    /// <summary>
    /// VisibleControl.xaml 的交互逻辑
    /// </summary>
    public partial class VisibleControl : UserControl
    {
        public VisibleControl()
        {
            //InitializeComponent();
        }
    }
}
