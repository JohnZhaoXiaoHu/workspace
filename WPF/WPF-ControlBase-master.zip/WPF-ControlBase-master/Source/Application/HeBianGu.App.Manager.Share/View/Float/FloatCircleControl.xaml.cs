﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Float
{
    /// <summary>
    /// CircleControl.xaml 的交互逻辑
    /// </summary>
    public partial class FloatCircleControl : UserControl
    {
        public FloatCircleControl()
        {
            InitializeComponent();
        }
    }
}
