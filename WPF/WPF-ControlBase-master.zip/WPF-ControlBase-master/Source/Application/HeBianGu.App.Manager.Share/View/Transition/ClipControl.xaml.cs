﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Transition
{
    /// <summary>
    /// ClipControl.xaml 的交互逻辑
    /// </summary>
    public partial class ClipControl : UserControl
    {
        public ClipControl()
        {
            //InitializeComponent();
        }
    }
}
