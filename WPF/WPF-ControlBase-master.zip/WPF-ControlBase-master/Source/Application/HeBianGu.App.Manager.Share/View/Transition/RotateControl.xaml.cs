﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Transition
{
    /// <summary>
    /// RotateControl.xaml 的交互逻辑
    /// </summary>
    public partial class RotateControl : UserControl
    {
        public RotateControl()
        {
            //InitializeComponent();
        }
    }
}
