﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Transition
{
    /// <summary>
    /// SkewControl.xaml 的交互逻辑
    /// </summary>
    public partial class SkewControl : UserControl
    {
        public SkewControl()
        {
            //InitializeComponent();
        }
    }
}
