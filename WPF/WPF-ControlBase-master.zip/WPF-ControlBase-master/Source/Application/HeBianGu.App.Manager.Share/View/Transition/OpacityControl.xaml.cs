﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Transition
{
    /// <summary>
    /// OpacityControl.xaml 的交互逻辑
    /// </summary>
    public partial class OpacityControl : UserControl
    {
        public OpacityControl()
        {
            //InitializeComponent();
        }
    }
}
