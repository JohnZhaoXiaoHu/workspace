﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Panel
{
    /// <summary>
    /// CrossControl.xaml 的交互逻辑
    /// </summary>
    public partial class CrossControl : UserControl
    {
        public CrossControl()
        {
            InitializeComponent();
        }
    }
}
