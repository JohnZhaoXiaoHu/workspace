﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Panel
{
    /// <summary>
    /// CoverControl.xaml 的交互逻辑
    /// </summary>
    public partial class CoverControl : UserControl
    {
        public CoverControl()
        {
            InitializeComponent();
        }
    }
}
