﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Panel
{
    /// <summary>
    /// ArcControl.xaml 的交互逻辑
    /// </summary>
    public partial class ArcControl : UserControl
    {
        public ArcControl()
        {
            InitializeComponent();
        }
    }
}
