﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Panel
{
    /// <summary>
    /// PageControl.xaml 的交互逻辑
    /// </summary>
    public partial class PageControl : UserControl
    {
        public PageControl()
        {
            //InitializeComponent();
        }
    }
}
