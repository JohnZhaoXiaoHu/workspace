﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Panel
{
    /// <summary>
    /// AnimationControl.xaml 的交互逻辑
    /// </summary>
    public partial class AnimationControl : UserControl
    {
        public AnimationControl()
        {
            InitializeComponent();
        }
    }
}
