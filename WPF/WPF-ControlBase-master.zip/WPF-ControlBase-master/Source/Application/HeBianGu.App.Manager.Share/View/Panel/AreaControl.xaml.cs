﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Panel
{
    /// <summary>
    /// AreaControl.xaml 的交互逻辑
    /// </summary>
    public partial class AreaControl : UserControl
    {
        public AreaControl()
        {
            InitializeComponent();
        }
    }
}
