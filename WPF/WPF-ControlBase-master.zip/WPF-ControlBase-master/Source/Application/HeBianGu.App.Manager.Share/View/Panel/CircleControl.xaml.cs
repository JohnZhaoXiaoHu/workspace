﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Panel
{
    /// <summary>
    /// CircleControl.xaml 的交互逻辑
    /// </summary>
    public partial class CircleControl : UserControl
    {
        public CircleControl()
        {
            InitializeComponent();
        }
    }
}
