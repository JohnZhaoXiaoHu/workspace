﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Drawer
{
    /// <summary>
    /// GeomotryControl.xaml 的交互逻辑
    /// </summary>
    public partial class GeomotryControl : UserControl
    {
        public GeomotryControl()
        {
            InitializeComponent();
        }
    }
}
