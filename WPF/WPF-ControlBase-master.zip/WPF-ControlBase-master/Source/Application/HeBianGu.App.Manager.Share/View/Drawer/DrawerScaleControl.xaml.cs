﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Drawer
{
    /// <summary>
    /// ScaleControl.xaml 的交互逻辑
    /// </summary>
    public partial class DrawerScaleControl : UserControl
    {
        public DrawerScaleControl()
        {
            InitializeComponent();
        }
    }
}
