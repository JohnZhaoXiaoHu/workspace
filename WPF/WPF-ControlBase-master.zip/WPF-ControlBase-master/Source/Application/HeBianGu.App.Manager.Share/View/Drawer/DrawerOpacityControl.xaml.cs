﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Drawer
{
    /// <summary>
    /// OpacityControl.xaml 的交互逻辑
    /// </summary>
    public partial class DrawerOpacityControl : UserControl
    {
        public DrawerOpacityControl()
        {
            InitializeComponent();
        }
    }
}
