﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Drawer
{
    /// <summary>
    /// AngleControl.xaml 的交互逻辑
    /// </summary>
    public partial class AngleControl : UserControl
    {
        public AngleControl()
        {
            InitializeComponent();
        }
    }
}
