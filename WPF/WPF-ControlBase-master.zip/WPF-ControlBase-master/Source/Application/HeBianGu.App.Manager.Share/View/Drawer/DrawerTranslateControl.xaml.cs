﻿using System.Windows.Controls;

namespace HeBianGu.App.Manager.View.Drawer
{
    /// <summary>
    /// TranslateControl.xaml 的交互逻辑
    /// </summary>
    public partial class DrawerTranslateControl : UserControl
    {
        public DrawerTranslateControl()
        {
            InitializeComponent();
        }
    }
}
