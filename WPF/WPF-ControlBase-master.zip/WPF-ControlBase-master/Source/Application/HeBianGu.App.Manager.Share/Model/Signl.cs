﻿namespace HeBianGu.App.Manager
{
    public class Student
    {
        public string Name { get; set; }

        public IXh Xh { get; set; }
    }

}
