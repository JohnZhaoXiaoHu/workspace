﻿namespace HeBianGu.App.Manager
{
    public interface IXh
    {

    }

    public class BJ : IXh
    {
        public ITz Tz { get; set; }
    }

    public class CD : IXh
    {
        public ITz Tz { get; set; }
    }
}
