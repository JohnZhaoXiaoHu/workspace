﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Loyout
{
    /// <summary>
    /// RadarAxisControl.xaml 的交互逻辑
    /// </summary>
    public partial class RadarAxisControl : UserControl
    {
        public RadarAxisControl()
        {
            InitializeComponent();
        }
    }
}
