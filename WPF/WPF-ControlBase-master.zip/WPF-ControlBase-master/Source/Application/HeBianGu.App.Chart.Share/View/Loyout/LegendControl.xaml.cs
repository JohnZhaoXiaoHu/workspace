﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Loyout
{
    /// <summary>
    /// LegendControl.xaml 的交互逻辑
    /// </summary>
    public partial class LegendControl : UserControl
    {
        public LegendControl()
        {
            InitializeComponent();
        }
    }
}
