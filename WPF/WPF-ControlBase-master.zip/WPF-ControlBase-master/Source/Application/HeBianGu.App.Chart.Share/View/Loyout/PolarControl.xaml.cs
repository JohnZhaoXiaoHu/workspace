﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Loyout
{
    /// <summary>
    /// PolarControl.xaml 的交互逻辑
    /// </summary>
    public partial class PolarControl : UserControl
    {
        public PolarControl()
        {
            InitializeComponent();
        }
    }
}
