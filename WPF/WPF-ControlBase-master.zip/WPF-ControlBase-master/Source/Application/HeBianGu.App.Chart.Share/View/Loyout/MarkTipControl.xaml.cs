﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Loyout
{
    /// <summary>
    /// MarkTipControl.xaml 的交互逻辑
    /// </summary>
    public partial class MarkTipControl : UserControl
    {
        public MarkTipControl()
        {
            InitializeComponent();
        }
    }
}
