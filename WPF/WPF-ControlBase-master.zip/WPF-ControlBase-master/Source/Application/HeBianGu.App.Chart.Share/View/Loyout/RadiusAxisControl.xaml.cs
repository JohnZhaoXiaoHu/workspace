﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Loyout
{
    /// <summary>
    /// RadiusAxisControl.xaml 的交互逻辑
    /// </summary>
    public partial class RadiusAxisControl : UserControl
    {
        public RadiusAxisControl()
        {
            InitializeComponent();
        }
    }
}
