﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Loyout
{
    /// <summary>
    /// FlagTipControl.xaml 的交互逻辑
    /// </summary>
    public partial class FlagTipControl : UserControl
    {
        public FlagTipControl()
        {
            InitializeComponent();
        }
    }
}
