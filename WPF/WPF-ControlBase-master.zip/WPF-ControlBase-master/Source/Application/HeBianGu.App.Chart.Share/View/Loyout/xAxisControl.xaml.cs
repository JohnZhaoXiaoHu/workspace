﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Loyout
{
    /// <summary>
    /// AxisControl.xaml 的交互逻辑
    /// </summary>
    public partial class xAxisControl : UserControl
    {
        public xAxisControl()
        {
            InitializeComponent();
        }
    }
}
