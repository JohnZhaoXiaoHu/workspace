﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Loyout
{
    /// <summary>
    /// GridControl.xaml 的交互逻辑
    /// </summary>
    public partial class GridControl : UserControl
    {
        public GridControl()
        {
            InitializeComponent();
        }
    }
}
