﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Loyout
{
    /// <summary>
    /// AngleAxisControl.xaml 的交互逻辑
    /// </summary>
    public partial class AngleAxisControl : UserControl
    {
        public AngleAxisControl()
        {
            InitializeComponent();
        }
    }
}
