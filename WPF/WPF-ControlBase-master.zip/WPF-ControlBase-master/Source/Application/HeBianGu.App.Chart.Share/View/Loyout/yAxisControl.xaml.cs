﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Loyout
{
    /// <summary>
    /// yAxisControl.xaml 的交互逻辑
    /// </summary>
    public partial class yAxisControl : UserControl
    {
        public yAxisControl()
        {
            InitializeComponent();
        }
    }
}
