﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Loyout
{
    /// <summary>
    /// VisualMapControl.xaml 的交互逻辑
    /// </summary>
    public partial class VisualMapControl : UserControl
    {
        public VisualMapControl()
        {
            InitializeComponent();
        }
    }
}
