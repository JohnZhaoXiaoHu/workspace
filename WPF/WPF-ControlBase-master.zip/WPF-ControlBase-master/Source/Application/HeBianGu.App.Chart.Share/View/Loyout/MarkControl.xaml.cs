﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Loyout
{
    /// <summary>
    /// MarkControl.xaml 的交互逻辑
    /// </summary>
    public partial class MarkControl : UserControl
    {
        public MarkControl()
        {
            InitializeComponent();
        }
    }
}
