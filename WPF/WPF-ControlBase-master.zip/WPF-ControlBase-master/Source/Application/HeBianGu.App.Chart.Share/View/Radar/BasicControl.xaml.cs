﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Radar
{
    /// <summary>
    /// BasicControl.xaml 的交互逻辑
    /// </summary>
    public partial class BasicControl : UserControl
    {
        public BasicControl()
        {
            InitializeComponent();
        }
    }
}
