﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Bar
{
    /// <summary>
    /// yBarControl.xaml 的交互逻辑
    /// </summary>
    public partial class yBarControl : UserControl
    {
        public yBarControl()
        {
            InitializeComponent();
        }
    }
}
