﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Bar
{
    /// <summary>
    /// yStackBarControl.xaml 的交互逻辑
    /// </summary>
    public partial class yStackBarControl : UserControl
    {
        public yStackBarControl()
        {
            InitializeComponent();
        }
    }
}
