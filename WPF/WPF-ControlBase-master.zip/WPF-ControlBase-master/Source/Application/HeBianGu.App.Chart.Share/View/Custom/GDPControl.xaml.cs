﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Custom
{
    /// <summary>
    /// GDPControl.xaml 的交互逻辑
    /// </summary>
    public partial class GDPControl : UserControl
    {
        public GDPControl()
        {
            InitializeComponent();
        }
    }
}
