﻿using System.Windows.Controls;

namespace HeBianGu.Application.ChartWindow.View.Custom
{
    /// <summary>
    /// CMapControl.xaml 的交互逻辑
    /// </summary>
    public partial class ThinningControl : UserControl
    {
        public ThinningControl()
        {
            //InitializeComponent();
        }
    }
}
