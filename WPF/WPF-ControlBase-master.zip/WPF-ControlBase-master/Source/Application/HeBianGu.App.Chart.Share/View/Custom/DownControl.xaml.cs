﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Custom
{
    /// <summary>
    /// DownControl.xaml 的交互逻辑
    /// </summary>
    public partial class DownControl : UserControl
    {
        public DownControl()
        {
            InitializeComponent();
        }
    }
}
