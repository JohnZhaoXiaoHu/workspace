﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Custom
{
    /// <summary>
    /// DistributionControl.xaml 的交互逻辑
    /// </summary>
    public partial class AreaControl : UserControl
    {
        public AreaControl()
        {
            InitializeComponent();
        }
    }
}
