﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Custom
{
    /// <summary>
    /// AnimationBarControl.xaml 的交互逻辑
    /// </summary>
    public partial class RichControl : UserControl
    {
        public RichControl()
        {
            InitializeComponent();
        }
    }
}
