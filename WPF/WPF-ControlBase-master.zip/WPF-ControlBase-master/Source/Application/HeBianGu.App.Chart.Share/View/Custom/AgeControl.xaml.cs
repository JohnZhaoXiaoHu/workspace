﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Custom
{
    /// <summary>
    /// AgeControl.xaml 的交互逻辑
    /// </summary>
    public partial class AgeControl : UserControl
    {
        public AgeControl()
        {
            InitializeComponent();
        }
    }
}
