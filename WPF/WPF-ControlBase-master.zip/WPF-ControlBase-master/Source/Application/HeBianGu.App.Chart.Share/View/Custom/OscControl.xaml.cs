﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Custom
{
    /// <summary>
    /// OscControl.xaml 的交互逻辑
    /// </summary>
    public partial class OscControl : UserControl
    {
        public OscControl()
        {
            InitializeComponent();
        }
    }
}
