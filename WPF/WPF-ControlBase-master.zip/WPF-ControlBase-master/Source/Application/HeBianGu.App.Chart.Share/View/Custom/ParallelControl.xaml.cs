﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Custom
{
    /// <summary>
    /// ParallelControl.xaml 的交互逻辑
    /// </summary>
    public partial class ParallelControl : UserControl
    {
        public ParallelControl()
        {
            InitializeComponent();
        }
    }
}
