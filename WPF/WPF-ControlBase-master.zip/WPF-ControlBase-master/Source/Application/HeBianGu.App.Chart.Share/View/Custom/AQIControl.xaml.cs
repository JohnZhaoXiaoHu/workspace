﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Custom
{
    /// <summary>
    /// AQIControl.xaml 的交互逻辑
    /// </summary>
    public partial class AQIControl : UserControl
    {
        public AQIControl()
        {
            InitializeComponent();
        }
    }
}
