﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Custom
{
    /// <summary>
    /// VisitControl.xaml 的交互逻辑
    /// </summary>
    public partial class VisitControl : UserControl
    {
        public VisitControl()
        {
            InitializeComponent();
        }
    }
}
