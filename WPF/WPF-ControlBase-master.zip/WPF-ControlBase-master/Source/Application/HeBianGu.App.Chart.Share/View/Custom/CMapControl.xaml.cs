﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Custom
{
    /// <summary>
    /// CMapControl.xaml 的交互逻辑
    /// </summary>
    public partial class CMapControl : UserControl
    {
        public CMapControl()
        {
            //InitializeComponent();
        }
    }
}
