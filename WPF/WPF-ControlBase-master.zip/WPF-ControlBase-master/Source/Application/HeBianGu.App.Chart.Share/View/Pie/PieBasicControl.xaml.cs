﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Pie
{
    /// <summary>
    /// BasicControl.xaml 的交互逻辑
    /// </summary>
    public partial class PieBasicControl : UserControl
    {
        public PieBasicControl()
        {
            InitializeComponent();
        }
    }
}
