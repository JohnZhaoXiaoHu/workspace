﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Map
{
    /// <summary>
    /// WorldControl.xaml 的交互逻辑
    /// </summary>
    public partial class WorldControl : UserControl
    {
        public WorldControl()
        {
            InitializeComponent();
        }
    }
}
