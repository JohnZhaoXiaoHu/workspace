﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Map
{
    /// <summary>
    /// ChinaControl.xaml 的交互逻辑
    /// </summary>
    public partial class ChinaControl : UserControl
    {
        public ChinaControl()
        {
            InitializeComponent();
        }
    }
}
