﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.K
{
    /// <summary>
    /// BaiscControl.xaml 的交互逻辑
    /// </summary>
    public partial class KBasicControl : UserControl
    {
        public KBasicControl()
        {
            InitializeComponent();
        }
    }
}
