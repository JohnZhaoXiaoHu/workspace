﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Scatter
{
    /// <summary>
    /// PolayControl.xaml 的交互逻辑
    /// </summary>
    public partial class ScatterPolarControl : UserControl
    {
        public ScatterPolarControl()
        {
            InitializeComponent();
        }
    }
}
