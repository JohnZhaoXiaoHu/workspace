﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Scatter
{
    /// <summary>
    /// BasicControl.xaml 的交互逻辑
    /// </summary>
    public partial class ScatterControl : UserControl
    {
        public ScatterControl()
        {
            InitializeComponent();
        }
    }
}
