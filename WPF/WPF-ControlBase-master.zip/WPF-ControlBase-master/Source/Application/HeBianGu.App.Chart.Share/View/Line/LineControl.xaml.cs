﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Line
{
    /// <summary>
    /// BasicControl.xaml 的交互逻辑
    /// </summary>
    public partial class LineControl : UserControl
    {
        public LineControl()
        {
            InitializeComponent();
        }
    }
}
