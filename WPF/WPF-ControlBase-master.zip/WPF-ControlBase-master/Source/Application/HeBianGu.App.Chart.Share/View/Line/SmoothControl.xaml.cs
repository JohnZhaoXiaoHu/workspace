﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Line
{
    /// <summary>
    /// SmoothControl.xaml 的交互逻辑
    /// </summary>
    public partial class SmoothControl : UserControl
    {
        public SmoothControl()
        {
            InitializeComponent();
        }
    }
}
