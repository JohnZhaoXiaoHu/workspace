﻿using System.Windows.Controls;

namespace HeBianGu.App.Chart.View.Line
{
    /// <summary>
    /// PolayControl.xaml 的交互逻辑
    /// </summary>
    public partial class LinePolarControl : UserControl
    {
        public LinePolarControl()
        {
            InitializeComponent();
        }
    }
}
