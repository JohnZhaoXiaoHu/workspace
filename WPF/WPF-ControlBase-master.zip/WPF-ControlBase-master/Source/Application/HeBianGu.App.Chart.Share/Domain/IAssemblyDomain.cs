﻿namespace HeBianGu.App.Chart
{
    public interface IAssemblyDomain
    {

    }
}