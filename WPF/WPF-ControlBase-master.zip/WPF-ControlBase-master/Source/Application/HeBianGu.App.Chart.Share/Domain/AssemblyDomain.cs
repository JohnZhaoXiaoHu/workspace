﻿namespace HeBianGu.App.Chart
{
    public class AssemblyDomain : IAssemblyDomain
    {

    }
}
