﻿using HeBianGu.Service.Mvc;
using System;

namespace HeBianGu.App.Chart
{
    [ViewModel("Pie")]
    internal class PieViewModel : MvcViewModelBase
    {

        protected override void Init()
        {

        }

        protected override void Loaded(string args)
        {

        }


    }
}
