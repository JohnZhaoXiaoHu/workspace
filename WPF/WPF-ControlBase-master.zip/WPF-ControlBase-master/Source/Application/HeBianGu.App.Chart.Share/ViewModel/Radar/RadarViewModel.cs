﻿using HeBianGu.Service.Mvc;
using System;

namespace HeBianGu.App.Chart
{
    [ViewModel("Radar")]
    internal class RadarViewModel : MvcViewModelBase
    {

        protected override void Init()
        {

        }

        protected override void Loaded(string args)
        {

        }


    }
}
