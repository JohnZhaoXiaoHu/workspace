﻿using HeBianGu.Service.Mvc;
using System;

namespace HeBianGu.App.Chart
{
    [ViewModel("Scatter")]
    internal class ScatterViewModel : MvcViewModelBase
    {

        protected override void Init()
        {

        }

        protected override void Loaded(string args)
        {

        }

    }
}
