﻿using HeBianGu.Service.Mvc;
using System;

namespace HeBianGu.App.Chart
{
    [ViewModel("Bar")]
    internal class BarViewModel : MvcViewModelBase
    {
        protected override void Init()
        {

        }

        private Random random = new Random();

        protected override void Loaded(string args)
        {

        }

    }
}
