﻿using System.Windows.Controls;

namespace HeBianGu.App.DownLoad.View.Home
{
    /// <summary>
    /// Interaction logic for HomeControl.xaml
    /// </summary>
    public partial class HomeControl : UserControl
    {
        public HomeControl()
        {
            InitializeComponent();
        }
    }
}
