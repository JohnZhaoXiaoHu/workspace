﻿using System.Windows.Controls;

namespace HeBianGu.App.DownLoad
{
    /// <summary>
    /// Interaction logic for MessageControl.xaml
    /// </summary>
    public partial class MessageControl : UserControl
    {
        public MessageControl()
        {
            InitializeComponent();
        }
    }
}
