﻿using System.Windows.Controls;

namespace HeBianGu.App.DownLoad.View.Home
{
    /// <summary>
    /// Interaction logic for DownLoadControl.xaml
    /// </summary>
    public partial class DownLoadControl : UserControl
    {
        public DownLoadControl()
        {
            InitializeComponent();
        }
    }
}
