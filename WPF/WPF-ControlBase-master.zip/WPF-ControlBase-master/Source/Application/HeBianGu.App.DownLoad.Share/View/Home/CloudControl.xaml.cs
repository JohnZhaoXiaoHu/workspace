﻿using System.Windows.Controls;

namespace HeBianGu.App.DownLoad
{
    /// <summary>
    /// Interaction logic for CloudControl.xaml
    /// </summary>
    public partial class CloudControl : UserControl
    {
        public CloudControl()
        {
            InitializeComponent();
        }
    }
}
