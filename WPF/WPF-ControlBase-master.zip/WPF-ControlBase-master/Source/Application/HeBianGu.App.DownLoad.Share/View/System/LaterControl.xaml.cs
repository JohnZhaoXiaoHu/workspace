﻿using System.Windows.Controls;

namespace HeBianGu.App.DownLoad
{
    /// <summary>
    /// Interaction logic for LaterControl.xaml
    /// </summary>
    public partial class LaterControl : UserControl
    {
        public LaterControl()
        {
            InitializeComponent();
        }
    }
}
