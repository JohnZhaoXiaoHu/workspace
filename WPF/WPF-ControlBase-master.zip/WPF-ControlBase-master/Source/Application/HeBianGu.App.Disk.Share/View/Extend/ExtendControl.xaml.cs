﻿using System.Windows.Controls;

namespace HeBianGu.App.Disk.Extend
{
    /// <summary>
    /// HomeControl.xaml 的交互逻辑
    /// </summary>
    public partial class ExtendControl : UserControl
    {
        public ExtendControl()
        {
            InitializeComponent();
        }
    }
}
