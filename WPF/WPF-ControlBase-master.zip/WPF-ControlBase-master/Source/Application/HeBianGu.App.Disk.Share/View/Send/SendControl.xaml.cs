﻿using System.Windows.Controls;

namespace HeBianGu.App.Disk.Send
{
    /// <summary>
    /// HomeControl.xaml 的交互逻辑
    /// </summary>
    public partial class SendControl : UserControl
    {
        public SendControl()
        {
            InitializeComponent();
        }
    }
}
