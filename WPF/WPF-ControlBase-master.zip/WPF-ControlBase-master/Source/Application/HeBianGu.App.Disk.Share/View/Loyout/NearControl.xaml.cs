﻿using System.Windows.Controls;

namespace HeBianGu.App.Disk
{
    /// <summary>
    /// NearControl.xaml 的交互逻辑
    /// </summary>
    public partial class NearControl : UserControl
    {
        public NearControl()
        {
            InitializeComponent();
        }
    }
}
