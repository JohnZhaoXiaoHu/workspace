﻿using System.Windows.Controls;

namespace HeBianGu.App.Disk.View.Custom
{
    /// <summary>
    /// HomeControl.xaml 的交互逻辑
    /// </summary>
    public partial class CustomControl : UserControl
    {
        public CustomControl()
        {
            InitializeComponent();
        }
    }
}
