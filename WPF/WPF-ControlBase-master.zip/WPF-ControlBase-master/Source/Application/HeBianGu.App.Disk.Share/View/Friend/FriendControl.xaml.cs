﻿using System.Windows.Controls;

namespace HeBianGu.App.Disk.View.Friend
{
    /// <summary>
    /// HomeControl.xaml 的交互逻辑
    /// </summary>
    public partial class FriendControl : UserControl
    {
        public FriendControl()
        {
            InitializeComponent();
        }
    }
}
