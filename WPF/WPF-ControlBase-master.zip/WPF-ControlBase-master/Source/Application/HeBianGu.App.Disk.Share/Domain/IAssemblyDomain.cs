﻿namespace HeBianGu.App.Disk
{
    public interface IAssemblyDomain
    {

    }
}