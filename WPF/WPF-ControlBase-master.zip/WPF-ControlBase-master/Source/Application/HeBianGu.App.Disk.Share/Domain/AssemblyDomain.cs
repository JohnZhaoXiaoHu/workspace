﻿namespace HeBianGu.App.Disk
{
    public class AssemblyDomain : IAssemblyDomain
    {

    }
}
