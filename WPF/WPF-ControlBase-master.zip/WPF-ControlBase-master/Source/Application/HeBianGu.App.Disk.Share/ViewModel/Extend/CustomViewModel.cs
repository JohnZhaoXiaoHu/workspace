﻿using HeBianGu.Service.Mvc;
using System;

namespace HeBianGu.App.Disk
{
    [ViewModel("Extend")]
    internal class ExtendViewModel : MvcViewModelBase
    {


        protected override void Init()
        {
        }

        protected override void Loaded(string args)
        {
        }


    }
}
