﻿// Copyright © 2022 By HeBianGu(QQ:908293466) https://github.com/HeBianGu/WPF-ControlBase

using System.Windows.Controls;

namespace HeBianGu.App.Music.View.Layout
{
    /// <summary>
    /// Interaction logic for LayoutControl.xaml
    /// </summary>
    public partial class LayoutControl : UserControl
    {
        public LayoutControl()
        {
            InitializeComponent();
        }
    }
}
