﻿namespace HeBianGu.App.Scene
{
    public interface IAssemblyDomain
    {

    }
}