﻿namespace HeBianGu.App.Scene
{
    public class AssemblyDomain : IAssemblyDomain
    {

    }
}
