﻿// Copyright © 2022 By HeBianGu(QQ:908293466) https://github.com/HeBianGu/WPF-ControlBase

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HeBianGu.App.Menu.View.Text
{
    /// <summary>
    /// Interaction logic for TextRandomBackControl.xaml
    /// </summary>
    public partial class TextRandomBackControl : UserControl
    {
        public TextRandomBackControl()
        {
            InitializeComponent();
        }
    }
}
