﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.TriggerAction
{
    /// <summary>
    /// GridControl.xaml 的交互逻辑
    /// </summary>
    public partial class FlashGridControl : UserControl
    {
        public FlashGridControl()
        {
            InitializeComponent();
        }
    }
}
