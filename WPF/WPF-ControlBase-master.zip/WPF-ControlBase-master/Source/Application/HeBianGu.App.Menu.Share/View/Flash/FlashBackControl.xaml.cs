﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.Flash
{
    /// <summary>
    /// BackControl.xaml 的交互逻辑
    /// </summary>
    public partial class FlashBackControl : UserControl
    {
        public FlashBackControl()
        {
            InitializeComponent();
        }
    }
}
