﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.Flash
{
    /// <summary>
    /// ElasticControl.xaml 的交互逻辑
    /// </summary>
    public partial class FlashElasticControl : UserControl
    {
        public FlashElasticControl()
        {
            InitializeComponent();
        }
    }
}
