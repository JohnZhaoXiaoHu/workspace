﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.TriggerAction
{
    /// <summary>
    /// FlashControl.xaml 的交互逻辑
    /// </summary>
    public partial class FlashControl : UserControl
    {
        public FlashControl()
        {
            InitializeComponent();
        }
    }
}
