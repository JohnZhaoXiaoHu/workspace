﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.Flash
{
    /// <summary>
    /// BounceControl.xaml 的交互逻辑
    /// </summary>
    public partial class FlashBounceControl : UserControl
    {
        public FlashBounceControl()
        {
            InitializeComponent();
        }
    }
}
