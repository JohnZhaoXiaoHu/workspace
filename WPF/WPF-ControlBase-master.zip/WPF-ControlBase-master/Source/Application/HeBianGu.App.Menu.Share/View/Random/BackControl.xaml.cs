﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.Random
{
    /// <summary>
    /// BackControl_.xaml 的交互逻辑
    /// </summary>
    public partial class BackControl : UserControl
    {
        public BackControl()
        {
            InitializeComponent();
        }
    }
}
