﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.Random
{
    /// <summary>
    /// OriginControl.xaml 的交互逻辑
    /// </summary>
    public partial class OriginControl : UserControl
    {
        public OriginControl()
        {
            InitializeComponent();
        }
    }
}
