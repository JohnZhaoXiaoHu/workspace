﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.Random
{
    /// <summary>
    /// TimeSplitControl.xaml 的交互逻辑
    /// </summary>
    public partial class UniformControl : UserControl
    {
        public UniformControl()
        {
            InitializeComponent();
        }
    }
}
