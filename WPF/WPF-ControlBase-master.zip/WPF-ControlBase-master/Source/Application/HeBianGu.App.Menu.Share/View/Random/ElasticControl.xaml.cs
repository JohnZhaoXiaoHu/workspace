﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.Random
{
    /// <summary>
    /// ElasticControl.xaml 的交互逻辑
    /// </summary>
    public partial class ElasticControl : UserControl
    {
        public ElasticControl()
        {
            InitializeComponent();
        }
    }
}
