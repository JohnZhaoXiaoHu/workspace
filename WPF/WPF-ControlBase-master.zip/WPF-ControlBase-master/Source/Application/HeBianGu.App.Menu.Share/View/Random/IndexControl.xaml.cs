﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.Random
{
    /// <summary>
    /// IndexControl.xaml 的交互逻辑
    /// </summary>
    public partial class IndexControl : UserControl
    {
        public IndexControl()
        {
            InitializeComponent();
        }
    }
}
