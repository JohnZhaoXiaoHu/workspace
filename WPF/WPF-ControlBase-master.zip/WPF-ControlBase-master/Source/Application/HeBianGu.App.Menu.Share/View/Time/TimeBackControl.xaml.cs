﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.TriggerAction
{
    /// <summary>
    /// BackControl.xaml 的交互逻辑
    /// </summary>
    public partial class TimeBackControl : UserControl
    {
        public TimeBackControl()
        {
            InitializeComponent();
        }
    }
}
