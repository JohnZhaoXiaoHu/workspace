﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.TriggerAction
{
    /// <summary>
    /// ElasticControl.xaml 的交互逻辑
    /// </summary>
    public partial class TimeElasticControl : UserControl
    {
        public TimeElasticControl()
        {
            InitializeComponent();
        }
    }
}
