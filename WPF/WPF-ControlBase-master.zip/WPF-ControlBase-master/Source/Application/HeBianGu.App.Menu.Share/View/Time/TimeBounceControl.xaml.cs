﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.TriggerAction
{
    /// <summary>
    /// BounceControl.xaml 的交互逻辑
    /// </summary>
    public partial class TimeBounceControl : UserControl
    {
        public TimeBounceControl()
        {
            InitializeComponent();
        }
    }
}
