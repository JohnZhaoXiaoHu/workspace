﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.Time
{
    /// <summary>
    /// HomeControl.xaml 的交互逻辑
    /// </summary>
    public partial class TimeControl : UserControl
    {
        public TimeControl()
        {
            InitializeComponent();
        }
    }
}
