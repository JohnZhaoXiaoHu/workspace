﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.Time
{
    /// <summary>
    /// TimeSplitControl.xaml 的交互逻辑
    /// </summary>
    public partial class TimeUniformControl : UserControl
    {
        public TimeUniformControl()
        {
            InitializeComponent();
        }
    }
}
