﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.Time
{
    /// <summary>
    /// StackControl.xaml 的交互逻辑
    /// </summary>
    public partial class TimeStackControl : UserControl
    {
        public TimeStackControl()
        {
            InitializeComponent();
        }
    }
}
