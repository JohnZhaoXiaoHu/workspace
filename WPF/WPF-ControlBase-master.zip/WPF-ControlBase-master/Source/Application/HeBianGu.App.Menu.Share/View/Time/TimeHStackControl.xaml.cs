﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.Time
{
    /// <summary>
    /// HStackControl.xaml 的交互逻辑
    /// </summary>
    public partial class TimeHStackControl : UserControl
    {
        public TimeHStackControl()
        {
            InitializeComponent();
        }
    }
}
