﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.Fluid
{
    /// <summary>
    /// StackControl.xaml 的交互逻辑
    /// </summary>
    public partial class FluidStackControl : UserControl
    {
        public FluidStackControl()
        {
            InitializeComponent();
        }
    }
}
