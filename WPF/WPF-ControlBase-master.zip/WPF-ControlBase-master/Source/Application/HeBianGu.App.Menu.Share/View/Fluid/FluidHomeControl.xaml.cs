﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.Fluid
{
    /// <summary>
    /// HomeControl.xaml 的交互逻辑
    /// </summary>
    public partial class FluidHomeControl : UserControl
    {
        public FluidHomeControl()
        {
            InitializeComponent();
        }
    }
}
