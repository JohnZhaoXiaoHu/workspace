﻿using System.Windows.Controls;

namespace HeBianGu.App.Menu.View.Fluid
{
    /// <summary>
    /// UniformControl.xaml 的交互逻辑
    /// </summary>
    public partial class FluidUniformControl : UserControl
    {
        public FluidUniformControl()
        {
            InitializeComponent();
        }
    }
}
