﻿namespace HeBianGu.App.Menu
{
    public interface IAssemblyDomain
    {

    }
}