﻿namespace HeBianGu.App.Menu
{
    public class AssemblyDomain : IAssemblyDomain
    {

    }
}
