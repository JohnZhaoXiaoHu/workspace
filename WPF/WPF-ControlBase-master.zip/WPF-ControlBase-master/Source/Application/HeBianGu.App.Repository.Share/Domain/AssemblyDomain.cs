﻿namespace HeBianGu.App.Repository
{
    public class AssemblyDomain : IAssemblyDomain
    {

    }
}
