﻿namespace HeBianGu.App.Repository
{
    public interface IAssemblyDomain
    {

    }
}