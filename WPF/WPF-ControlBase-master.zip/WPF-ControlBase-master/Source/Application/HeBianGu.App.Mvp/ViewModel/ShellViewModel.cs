﻿using HeBianGu.Base.WpfBase;

namespace HeBianGu.App.Mvp
{
    internal class ShellViewModel : NotifyPropertyChanged
    {
        protected override void Init()
        {

        }

        /// <summary> 命令通用方法 </summary>
        protected override async void RelayMethod(object obj)

        {

        }
    }
}
