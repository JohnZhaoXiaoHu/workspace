﻿using HeBianGu.Service.Mvc;

namespace HeBianGu.App.Media.ViewModel.Set
{
    /// <summary> 说明</summary>
    internal class SetViewModel : MvcViewModelBase
    {
        #region - 属性 -

        #endregion

        #region - 命令 -

        #endregion

    }
}
