﻿using HeBianGu.Service.Mvc;
using System;

namespace HeBianGu.App.Media.ViewModel.Home
{
    [ViewModel("Home")]
    internal class HomeViewModel : MvcViewModelBase
    {
        #region - 属性 -

        #endregion

        #region - 命令 -

        #endregion
    }

}
