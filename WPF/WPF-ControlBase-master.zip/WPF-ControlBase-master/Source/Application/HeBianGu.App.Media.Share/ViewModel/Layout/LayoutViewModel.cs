﻿using HeBianGu.App.Media.View.Layout.Dialog;
using HeBianGu.Base.WpfBase;
using HeBianGu.General.WpfControlLib;
using HeBianGu.Service.Mvc;
using System;
using System.Windows;

namespace HeBianGu.App.Media.ViewModel.Layout
{
    [ViewModel("Layout")]
    internal class LayoutViewModel : MvcViewModelBase
    {
        #region - 属性 -

        #endregion

        #region - 命令 -

        #endregion
    }

}
