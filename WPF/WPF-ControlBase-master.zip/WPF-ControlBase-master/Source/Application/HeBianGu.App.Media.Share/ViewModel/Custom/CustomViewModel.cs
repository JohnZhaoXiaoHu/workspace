﻿using HeBianGu.Service.Mvc;
using System;

namespace HeBianGu.App.Media.ViewModel.Custom
{
    [ViewModel("Custom")]
    internal class CustomViewModel : MvcViewModelBase
    {
        #region - 属性 -

        #endregion

        #region - 命令 -

        #endregion
    }

}
