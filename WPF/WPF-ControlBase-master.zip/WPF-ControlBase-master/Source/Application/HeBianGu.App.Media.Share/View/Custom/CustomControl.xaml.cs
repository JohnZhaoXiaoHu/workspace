﻿using System.Windows.Controls;

namespace HeBianGu.App.Media.View.Custom
{
    /// <summary>
    /// Interaction logic for CustomControl.xaml
    /// </summary>
    public partial class CustomControl : UserControl
    {
        public CustomControl()
        {
            InitializeComponent();
        }
    }
}
