﻿using System.Windows.Controls;

namespace HeBianGu.App.Media.View.Layout
{
    /// <summary>
    /// Interaction logic for LayoutControl.xaml
    /// </summary>
    public partial class LayoutControl : UserControl
    {
        public LayoutControl()
        {
            InitializeComponent();
        }
    }
}
