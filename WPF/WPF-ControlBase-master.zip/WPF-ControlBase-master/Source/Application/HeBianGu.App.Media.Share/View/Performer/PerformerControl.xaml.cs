﻿using System.Windows.Controls;

namespace HeBianGu.App.Media.View.Performer
{
    /// <summary>
    /// Interaction logic for PerformerControl.xaml
    /// </summary>
    public partial class PerformerControl : UserControl
    {
        public PerformerControl()
        {
            InitializeComponent();
        }
    }
}
