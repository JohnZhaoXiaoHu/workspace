﻿using System.Windows.Controls;

namespace HeBianGu.App.Media.View.Set
{
    /// <summary>
    /// Interaction logic for SetControl.xaml
    /// </summary>
    public partial class SetControl : UserControl
    {
        public SetControl()
        {
            InitializeComponent();
        }
    }
}
