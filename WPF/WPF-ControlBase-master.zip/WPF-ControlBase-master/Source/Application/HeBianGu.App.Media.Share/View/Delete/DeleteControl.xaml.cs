﻿using System.Windows.Controls;

namespace HeBianGu.App.Media.View.Delete
{
    /// <summary>
    /// Interaction logic for DeleteControl.xaml
    /// </summary>
    public partial class DeleteControl : UserControl
    {
        public DeleteControl()
        {
            InitializeComponent();
        }
    }
}
