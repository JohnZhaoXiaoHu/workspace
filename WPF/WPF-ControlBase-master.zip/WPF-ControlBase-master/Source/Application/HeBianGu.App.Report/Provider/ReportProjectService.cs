﻿using HeBianGu.Base.WpfBase;
using HeBianGu.Service.AppConfig;
using HeBianGu.Systems.Project;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeBianGu.App.Report.Provider
{
    public class ReportProjectService : ProjectService
    {

    }
}
