﻿namespace HeBianGu.App.Office
{
    public class AssemblyDomain : IAssemblyDomain
    {

    }
}
