﻿namespace HeBianGu.App.Office
{
    public interface IAssemblyDomain
    {

    }
}