﻿using HeBianGu.Base.WpfBase;

namespace HeBianGu.App.Office
{
    internal class ShellViewModel : NotifyPropertyChanged
    {

        protected override void Init()
        {

        }

    }
}
