﻿using System.Windows.Controls;

namespace HeBianGu.App.Office.View.Loyout
{
    /// <summary>
    /// ConnnectControl.xaml 的交互逻辑
    /// </summary>
    public partial class ConnectControl : UserControl
    {
        public ConnectControl()
        {
            InitializeComponent();
        }
    }
}
