﻿using System.Windows.Controls;

namespace HeBianGu.App.Office.View.Loyout
{
    /// <summary>
    /// HomeControl.xaml 的交互逻辑
    /// </summary>
    public partial class HomeControl : UserControl
    {
        public HomeControl()
        {
            InitializeComponent();
        }
    }
}
