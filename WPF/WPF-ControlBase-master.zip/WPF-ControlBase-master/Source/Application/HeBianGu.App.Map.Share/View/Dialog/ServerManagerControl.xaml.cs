﻿using System.Windows.Controls;

namespace HeBianGu.App.Map.View.Dialog
{
    /// <summary>
    /// ServerManagerControl.xaml 的交互逻辑
    /// </summary>
    public partial class ServerManagerControl : UserControl
    {
        public ServerManagerControl()
        {
            InitializeComponent();
        }
    }
}
