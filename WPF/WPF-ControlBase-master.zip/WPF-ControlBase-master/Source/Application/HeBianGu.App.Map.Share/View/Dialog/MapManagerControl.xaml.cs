﻿using System.Windows.Controls;

namespace HeBianGu.App.Map.View.Dialog
{
    /// <summary>
    /// MapManagerControl.xaml 的交互逻辑
    /// </summary>
    public partial class MapManagerControl : UserControl
    {
        public MapManagerControl()
        {
            InitializeComponent();
        }
    }
}
