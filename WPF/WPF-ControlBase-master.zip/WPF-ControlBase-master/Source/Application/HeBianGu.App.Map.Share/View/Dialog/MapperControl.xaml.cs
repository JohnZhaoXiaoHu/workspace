﻿using System.Windows.Controls;

namespace HeBianGu.App.Map.View.Dialog
{
    /// <summary>
    /// MapperControl.xaml 的交互逻辑
    /// </summary>
    public partial class MapperControl : UserControl
    {
        public MapperControl()
        {
            InitializeComponent();
        }
    }
}
