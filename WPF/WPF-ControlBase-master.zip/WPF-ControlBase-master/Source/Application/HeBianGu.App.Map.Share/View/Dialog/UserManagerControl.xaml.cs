﻿using System.Windows.Controls;

namespace HeBianGu.App.Map.View.Dialog
{
    /// <summary>
    /// UserManagerControl.xaml 的交互逻辑
    /// </summary>
    public partial class UserManagerControl : UserControl
    {
        public UserManagerControl()
        {
            InitializeComponent();
        }
    }
}
