﻿using System.Windows.Controls;

namespace HeBianGu.App.Map.View.Dialog
{
    /// <summary>
    /// EquipManagerControl.xaml 的交互逻辑
    /// </summary>
    public partial class EquipManagerControl : UserControl
    {
        public EquipManagerControl()
        {
            InitializeComponent();
        }
    }
}
