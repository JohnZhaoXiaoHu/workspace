﻿using System.Windows.Controls;

namespace WpfControlDemo.View
{
    /// <summary>
    /// TabControlPage.xaml 的交互逻辑
    /// </summary>
    public partial class TabControlPage : Page
    {
        public TabControlPage()
        {
            InitializeComponent();
        }
    }
}
