﻿using System.Windows.Controls;

namespace WpfControlDemo.View
{
    /// <summary>
    /// FramePage.xaml 的交互逻辑
    /// </summary>
    public partial class FramePage : Page
    {
        public FramePage()
        {
            InitializeComponent();
        }
    }
}
