﻿using System.Windows.Controls;

namespace HeBianGu.Applications.ControlBase.Demo.Pages
{
    /// <summary>
    /// FormPage.xaml 的交互逻辑
    /// </summary>
    public partial class FormPage : Page
    {
        public FormPage()
        {
            InitializeComponent();
        }
    }
}
