﻿using System.Windows.Controls;

namespace WpfControlDemo.View
{
    /// <summary>
    /// CheckBoxPage.xaml 的交互逻辑
    /// </summary>
    public partial class CheckBoxPage : Page
    {
        public CheckBoxPage()
        {
            InitializeComponent();
        }
    }
}
