﻿using System.Windows.Controls;

namespace HeBianGu.Applications.ControlBase.Demo.Pages
{
    /// <summary>
    /// StoryBoardPlayerPage.xaml 的交互逻辑
    /// </summary>
    public partial class StoryBoardPlayerPage : Page
    {
        public StoryBoardPlayerPage()
        {
            InitializeComponent();
        }
    }
}
