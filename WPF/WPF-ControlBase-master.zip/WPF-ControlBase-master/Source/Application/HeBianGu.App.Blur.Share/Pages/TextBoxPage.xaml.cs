﻿using System.Windows.Controls;

namespace WpfControlDemo.View
{
    /// <summary>
    /// TextBoxPage.xaml 的交互逻辑
    /// </summary>
    public partial class TextBoxPage : Page
    {
        public TextBoxPage()
        {
            InitializeComponent();
        }
    }
}
