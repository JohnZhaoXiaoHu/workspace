﻿using System.Windows.Controls;

namespace HeBianGu.App.Blur.Pages
{
    /// <summary>
    /// StoryBoardPathPage.xaml 的交互逻辑
    /// </summary>
    public partial class StoryBoardPathPage : Page
    {
        public StoryBoardPathPage()
        {
            InitializeComponent();
        }
    }
}
