﻿using System.Windows.Controls;

namespace WpfControlDemo.View
{
    /// <summary>
    /// ToggleButtonPage.xaml 的交互逻辑
    /// </summary>
    public partial class ToggleButtonPage : Page
    {
        public ToggleButtonPage()
        {
            InitializeComponent();
        }
    }
}
