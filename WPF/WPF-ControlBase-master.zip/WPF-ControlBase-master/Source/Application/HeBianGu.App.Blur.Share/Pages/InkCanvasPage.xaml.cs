﻿using System.Windows.Controls;

namespace WpfControlDemo.View
{
    /// <summary>
    /// InkCanvasPage.xaml 的交互逻辑
    /// </summary>
    public partial class InkCanvasPage : Page
    {
        public InkCanvasPage()
        {
            InitializeComponent();
        }
    }
}
