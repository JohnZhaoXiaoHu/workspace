﻿using System.Windows.Controls;

namespace HeBianGu.Applications.ControlBase.Demo.Pages
{
    /// <summary>
    /// DataGridPage.xaml 的交互逻辑
    /// </summary>
    public partial class DataGridPage : Page
    {
        public DataGridPage()
        {
            InitializeComponent();
        }
    }
}
