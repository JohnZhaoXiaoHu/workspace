﻿using System.Windows.Controls;

namespace WpfControlDemo.View
{
    /// <summary>
    /// WaterFallPage.xaml 的交互逻辑
    /// </summary>
    public partial class WaterFallPage : Page
    {
        public WaterFallPage()
        {
            InitializeComponent();
        }
    }
}
