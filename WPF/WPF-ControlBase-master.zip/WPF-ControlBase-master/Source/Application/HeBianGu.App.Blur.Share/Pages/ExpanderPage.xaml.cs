﻿using System.Windows.Controls;

namespace WpfControlDemo.View
{
    /// <summary>
    /// ExpanderPage.xaml 的交互逻辑
    /// </summary>
    public partial class ExpanderPage : Page
    {
        public ExpanderPage()
        {
            InitializeComponent();
        }
    }
}
