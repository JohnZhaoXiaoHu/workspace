﻿using System.Windows.Controls;

namespace WpfControlDemo.View
{
    /// <summary>
    /// TreeViewPage.xaml 的交互逻辑
    /// </summary>
    public partial class TreeListViewPage : Page
    {
        public TreeListViewPage()
        {
            InitializeComponent();
        }
    }
}
