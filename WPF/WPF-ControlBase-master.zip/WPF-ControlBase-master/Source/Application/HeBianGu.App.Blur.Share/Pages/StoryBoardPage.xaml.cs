﻿using System.Windows.Controls;

namespace WpfControlDemo.View
{
    /// <summary>
    /// StoryBoardPage.xaml 的交互逻辑
    /// </summary>
    public partial class StoryBoardPage : Page
    {
        public StoryBoardPage()
        {
            InitializeComponent();
        }
    }
}
