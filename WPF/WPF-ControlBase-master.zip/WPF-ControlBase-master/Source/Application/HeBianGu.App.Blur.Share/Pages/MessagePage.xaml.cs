﻿using System.Windows.Controls;

namespace HeBianGu.Applications.ControlBase.Demo.Pages
{
    /// <summary>
    /// MessagePage.xaml 的交互逻辑
    /// </summary>
    public partial class MessagePage : Page
    {
        public MessagePage()
        {
            InitializeComponent();
        }
    }
}
