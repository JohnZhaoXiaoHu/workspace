﻿using System.Windows.Controls;

namespace HeBianGu.App.Blur.Pages
{
    /// <summary>
    /// RenderTransformPage.xaml 的交互逻辑
    /// </summary>
    public partial class RenderTransformPage : Page
    {
        public RenderTransformPage()
        {
            InitializeComponent();
        }
    }
}
