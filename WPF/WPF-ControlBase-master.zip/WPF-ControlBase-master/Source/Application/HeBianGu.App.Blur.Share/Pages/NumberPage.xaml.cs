﻿using System.Windows.Controls;

namespace WpfControlDemo.View
{
    /// <summary>
    /// NumberPage.xaml 的交互逻辑
    /// </summary>
    public partial class NumberPage : Page
    {
        public NumberPage()
        {
            InitializeComponent();
        }
    }
}
