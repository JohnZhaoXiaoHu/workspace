﻿namespace HeBianGu.App.Cross
{
    public class AssemblyDomain : IAssemblyDomain
    {

    }
}
