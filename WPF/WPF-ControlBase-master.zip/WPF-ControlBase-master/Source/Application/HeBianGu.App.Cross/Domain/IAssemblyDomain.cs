﻿namespace HeBianGu.App.Cross
{
    public interface IAssemblyDomain
    {

    }
}